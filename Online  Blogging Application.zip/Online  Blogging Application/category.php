<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>OnlineBloggingApplication</title>
  <style type="text/css">
    .links_category_blog{
      text-decoration: none;
      font-weight: bolder;
      font-family: cursive;
    }
    .links_category_blog:hover{
      color: green;
    }
  </style>
 

</head>
<body>
     
          
      <!-- Navbar  -->
      <?php include_once("navbar.php"); ?>
         <!-- Navbar End -->
        
           <script type="text/javascript">
                 setInterval(function(){
                  document.getElementById("message").innerHTML = "";
                      },5000);
              </script>


                <?php 
                    if(isset($_REQUEST['msg'])){
                      ?>
                      <div id="message" style="text-align: center;"><?php  echo "<h3 style='color:".$_REQUEST['color']."'>".$_REQUEST['msg']."</h3>";?> 
                      </div>
                 <?php
                     
                    }
                 ?>
             <!-- Login  -->
          <?php include_once("login-page.php"); ?>
             <!--  End -->

           
      <!-- 2 Column Layout -->
      <div class="row ">
        <!-- First Column -->
         <div class="col-9  text-center p-2 fw-bolder ">

           <!-- Page Name -->
          <div class="row container">
              <div class="col  m-2 fw-bold ">
                 <h2 class="text-uppercase fw-bolder" style="text-decoration-thickness:5px; text-decoration-color: #F6B608 ;  text-underline-offset:15px; color: black; text-align: left;" id="about_us_heading"> <?php// echo $row['blog_title']; ?> 


                 </h2>  
                 <div>

              </div>
              </div>
          </div>

            
          
  <?php
   if (isset($_GET['category_id'])) {
              $catgry=$_GET['category_id'];
            
           $select_query_for_post_category = "SELECT  category.*, post.`post_title`, post.`post_summary`,post.`post_id`, post.`post_description`, post.`featured_image`  FROM category 
                    INNER JOIN post_category
                    ON category.`category_id` = post_category.`category_id`
                    INNER JOIN post
                    ON post_category.`post_id` = post.`post_id`
                    WHERE category.`category_id` = ".$catgry;  
            $result = mysqli_query($connection,$select_query_for_post_category);

            if(mysqli_num_rows($result) > 0)
            {   
            while ($row= mysqli_fetch_assoc($result)) {
              
            ?>
            <!-- Post  -->
              <div class="container">
               <div class="card mb-3" style="max-width: 100%;">
                  <div class="row g-0">
                    <div class="col-md-4">
                      <img src="admin/<?php  echo $row['featured_image'];  ?>" width="100%" height="100%">
                     
                    </div>
                    <div class="col-md-8">
                      <div class="card-body">
                        <div class="row">
                         
                           <div class="col-12">
                            <a class="links_category_blog" href="" ><h5 class="card-title">
                              <?php  echo $row['category_title'];  ?>
                            </h5></a>
                          </div>
                         
                          <h5 class="card-title">
                            <?php  echo $row['post_title'];  ?>
                          </h5>
                        </div>
                        
                        <p class="card-text">
                          <?php  echo $row['post_summary'];  ?>
                        </p>
                        <p class="card-text"><small class="text-body-secondary">Last updated 3 mins ago</small></p>
                            <a href="post-readmore-page.php?post_id=<?php echo $row['post_id'];?>" class="btn btn-primary" >Read More</a>

                      </div>
                    </div>
                  </div>
                </div>
              </div>

             <?php   
               } }
              else{
                echo "No Blogs";
              }
            

              
                }  ?>
            <!-- Post End-->

          </div>
              <!-- First Column End -->
         

         <div class="col-3 text-center p-2 fw-bolder ">
          <!-- Second Column -->

          <!--Recent News  -->
            <?php  include("recent-news.php"); ?>
           <!-- Recent News -->
          
         </div>
         <!-- Second Column End -->
       
          <!-- Contact us -->
          <?php  include_once("contact-us.php") ?>
          <!-- Contact us End-->
        
          <!-- About Us -->
              <?php include_once("about-us.php"); ?>
          <!-- About us End -->

          <!-- Footer -->
            <?php 
              include_once("footer.php");
            ?>
          <!-- Footer End -->


</body>
</html>