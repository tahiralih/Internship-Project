<?php
session_start();
require_once 'database-files/connection.php';
date_default_timezone_set("asia/karachi");

?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>OnlineBloggingApplication</title>
 
   <style type="text/css">
         .comment-section {
            margin-top: 50px;
          }

          .comment {
            margin-bottom: 20px;
            border: 1px solid #ddd;
            padding: 10px;
          }

          .comment-header {
            display: flex;
            align-items: center;
            margin-bottom: 10px;
          }

          .comment-header img {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            margin-right: 10px;
          }

          .comment-header h4 {
            margin: 0;
          }

          .comment-header .date {
            margin-left: auto;
          }

          .comment-body {
            margin: 0;
          }

          .comment-form {
            margin-top: 50px;
          }

          .comment-form h3 {
            margin-bottom: 20px;
          }

          .form-group {
            margin-bottom: 20px;
          }

          label {
            display: block;
            margin-bottom: 5px;
          }


          input,
          textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 15px;

          }

    
          #commentbtn{
            display: block;
            float: right;
            width: 20%;
            margin: 10px 0;
             background-color: black;
            color: white;
          }
           #commentbtn:hover{
            color: black;
            background-color: gray;

          }
          </style>
</head>
<body>

       
     
        <!-- Navbar  -->
      <?php include_once("login-page.php"); ?>
       <!-- Navbar End -->
     
          
        <!-- Navbar  -->
      <?php include_once("navbar.php"); ?>
       <!-- Navbar End -->

          
  <?php
    
    $post_id=$_REQUEST['post_id'];

    $select_query = "SELECT   POST.`post_title`,POST.`featured_image`,
              POST.`post_summary`,POST.`post_description`,POST_ATACHMENT.`post_attachment_path`
              FROM POST 
              INNER JOIN BLOG
              ON BLOG.`blog_id`=POST.`blog_id`
              INNER JOIN POST_ATACHMENT
              ON POST_ATACHMENT.`post_id`=POST.`post_id`
              WHERE POST.`post_status`='Active' AND POST.`post_id`=$post_id AND BLOG.`blog_status`='Active';";
            $result = mysqli_query($connection,$select_query);

            if(mysqli_num_rows($result) > 0)
            {
      
              $row = mysqli_fetch_assoc($result)
                
                    
                    
                 ?>
        <!-- main row -->
          <div class="row" >

            <div class="col-12">  
            <div class="container">
          
              <div class="card-body">
                <h2 class="card-title">Post Description</h2>
                <p class="card-text">
                  <?php echo $row['post_description']; ?>
                </p>
              </div>
              

               <div class="row row-cols-1 row-cols-md-3 g-4 my-3">
                 <?php
                  while ($row = mysqli_fetch_assoc($result)) {
                  ?>
                  <div class="col-4">
                    <div class="card h-100">
                      <img src="admin/Post-Attachment-Images/<?php echo $row['post_attachment_path']; ?>" class="card-img-bottom" alt="No Attachment Image" height="400px">
                    </div>
                  </div>
                   <?php 
                } ?>
                </div> 

               <?php
               }   
              else{
                echo "No Posts";
              }
              ?>

          <form action="home-page.php?msg=Please login first then you can comment&color=red" method="POST">
                <div >
                  <h2>Comment:</h2>
                  <textarea id="comment" name="comment" required></textarea>
                </div>
                <input id="commentbtn" type="submit" name="comment_submit" value="Send Comment" class="fw-bold"> 
            
          </form>
        <!-- comment end -->

             </div> 

            </div>

          </div>
          <!-- main row end -->

      <!-- Footer -->
        <?php 
          include_once("footer.php");
        ?>
      <!-- Footer End -->

</body>
</html>