<?php 

	require_once '../database-files/connection.php';

	function getAllUsers()
	{
		global $connection;
		$query = "SELECT * FROM user";
		$result = mysqli_query($connection,$query);
		return $result;
	} 
	function AddFormUser($action ="",$method="GET")
	{
    global $connection;
   ?>

      <center>
        <fieldset class="my-5 bg-dark ">
          <legend class="fw-bolder"> Add User Here </legend>
        
            <form method="<?php echo $method; ?>" action="<?php echo $action; ?>" enctype="multipart/form-data">  
               <table id="user_form">

                  <tr>
                    <td class="fw-bold">First Name</td>
                      
                    <td class="form-group" >
                      <input  type="text" name="first_name" placeholder="Enter user First name" required>
                    </td>
                  </tr>

                   <tr>
                    <td class="fw-bold">Last Name</td>
                      
                    <td class="form-group" >
                      <input  type="text" name="last_name" placeholder="Enter user Last name" required>
                    </td>
                  </tr>

                   <tr>
                    <td class="fw-bold">Email</td>
                      
                    <td class="form-group" >
                      <input  type="text" name="email" placeholder="Enter user Email" required>
                    </td>
                  </tr>

                  <tr>
                    <td class="fw-bold">Password</td>
                      
                    <td class="form-group" >
                      <input  type="text" name="password" placeholder="Enter user Password" required>
                    </td>
                  </tr>

                  <tr>
                    <td class="fw-bold">Gender</td>
                    <td>
                      Male <input type="radio" name="gender" value="male" id="gender_male"> 
                        Female <input type="radio" name="gender" value="female" id="gender_female">     
                    </td>
                  </tr>

                  <tr>
                    <td class="fw-bold ">Date of Birth</td>
                      <td><input class="text-black" type="date" name="date_of_birth"  required></td>
                    </td>
                  </tr>

                  <tr>
                    <td class="fw-bold">Address</td>
                      <td><textarea class="text-black" name="address" ></textarea></td>
                    </td>
                  </tr>
                  
                  <tr>
                    <td class="fw-bold"> Status </td>
                    <td >Active <input type="radio" name="status" value="Active" class="mx-4" required> 
                      InActive <input type="radio" name="status" value="InActive" class="mx-4" required>
                    </td>
                  </tr>

                  <tr>
                    <td class="fw-bold"> User Role </td>
                    <td> 
                        <?php 
                          $select_query = "SELECT * FROM ROLE"; 
                    $result = mysqli_query($connection,$select_query);

                    if(mysqli_num_rows($result) > 0)
                    {
              
                      while($row = mysqli_fetch_assoc($result))
                      {
                        ?>
                      
                        <?php
                        }
                      }
                        ?>
                    </td>
                  </tr>

                    <tr>
                    <td class="fw-bold">Upload User Image</td>
                      <td class="form-group" >
                        <input class="text-white" type="file" name="user_image" enctype="multipart/form-data" />
                      </td>
                  <tr>

                  
                    <tr>
                    <td colspan="2" align="center">
                       <input type="submit" name="add_user" value="Add User" >
                    </td>
                  </tr>
                  </table>
                </form>
              </fieldset>
          </center>

          <h1 class="fw-bold text-center"> Manage Users </h1>
          		<?php
	}

	function getUserByUserId($user_id)
	{
		global $connection;
		$query = "SELECT * FROM `user` WHERE `user`.`user_id` = $user_id";
		$res = mysqli_query($connection,$query);
		$data = mysqli_fetch_assoc($res);	
		return $data;
	}

	function EditFormUser($action = "",$method="GET",$user_id)
	{

		$data = getUserByUserId($user_id);

		

		?>


		  <center>
        <fieldset class="my-5 bg-dark">
          <legend class="fw-bolder"> Edit User Here..! </legend>
				
        
            <form method="<?php echo $method; ?>" action="<?php echo $action; ?>" enctype="multipart/form-data">  
            <input type="hidden" name="user_id" value="<?php echo $data['user_id'];?>">
               <table id="user_form">


                   <tr>
                    <td class="fw-bold">First Name</td>
                      
                    <td class="form-group" >
                      <input  type="text" name="first_name" value="<?php echo $data['first_name'];?>" placeholder="Enter user First name" required>
                    </td>
                  </tr>

                   <tr>
                    <td class="fw-bold">Last Name</td>
                      
                    <td class="form-group" >
                      <input  type="text" name="last_name" value="<?php echo $data['last_name'];?>" placeholder="Enter user Last name" required>
                    </td> 
                  </tr>

                   <tr>
                    <td class="fw-bold">Email</td>
                      
                    <td class="form-group" >
                      <input  type="text" name="email" value="<?php echo $data['email'];?>" placeholder="Enter user Email" required>
                    </td>
                  </tr>

                  <tr>
                    <td class="fw-bold">Password</td>
                      
                    <td class="form-group" >
                      <input  type="text" name="password" value="<?php echo $data['password'];?>" placeholder="Enter user Email" required>
                    </td>
                  </tr>

                 <tr>
                    <td class="fw-bold">Gender</td>
                    <td>
                    Male <input type="radio" name="gender"  value="Male" <?php echo ($data['gender'] == "Male")?'checked':'';?>  class="mx-4" required> 
                      Female <input type="radio" name="gender" value="Female" <?php echo ($data['gender'] == "Female")?'checked':'';?> class="mx-4" required>
                    </td>
                   
                  </tr>

                  <tr>
                    <td class="fw-bold">Date of Birth</td>
                     <td> <input class="text-black" type="date" value="<?php echo $data['date_of_birth'];?>" name="date_of_birth"  required>
                    </td>
                  </tr>

                  <tr>
                    <td class="fw-bold">Address</td>
                      <td><textarea class="text-black" name="address"> <?php echo $data['address'];?> </textarea></td>
                    </td>
                  </tr>
                  
                  <tr>
                    <td class="fw-bold"> User Status </td>
                    <td>Active <input type="radio" name="status"  value="Active" <?php echo ($data['is_active'] == "Active")?'checked':'';?>  class="mx-4" required> 
                      InActive <input type="radio" name="status" value="InActive" <?php echo ($data['is_active'] == "InActive")?'checked':'';?> class="mx-4" required>
                    </td>
                  
                  </tr>

                   <tr>
                    <td class="fw-bold">Upload User Image</td>
                      <td class="form-group" >
                        <input class="text-white" type="file" name="user_image" enctype="multipart/form-data" />
                         <td><img src="<?php echo $data['user_image']; ?>" width="40px" height="40px" alt="No image select"></td>
                      </td>
                    <tr>

                 

                    <td colspan="2" align="center">
                       <input type="submit" name="update_user" value="Update User" >
                    </td>
                  </tr>
                  </table>
                </form>
              </fieldset>
          </center>
          		<?php
	}

       
	
	

?>