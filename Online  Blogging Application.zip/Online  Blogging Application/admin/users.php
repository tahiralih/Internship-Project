<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
  <title>Online Blogging Application</title>
  <style type="text/css">
    *{
      color: white;
      box-sizing: border-box;
    }
      input[type=submit] {
        background-color: #0080ff; 
        border: none;
        color: white;
        padding: 10px 20px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 25px;
        margin: 4px 50px;
        cursor: pointer;

      } 



 .form-group input{
   text-align: center;
   display: block;
   width: 100%;
   padding: 2px;
   margin: 16px auto;
   font-size: 25px;
   border: 5px groove #0080ff;
   border-radius: 15px;
   font-family: 'cursive;';
   color: black;
    }


    fieldset{
      margin-top: 20px;
      width: 80%;
      height: 50%;
      border-radius: 20px;
      border: 5px solid #0080ff;  
      color: white; 
    }

    table {
          border-collapse: collapse;
          margin-top: 20px;
        }

        th, td {
          padding: 15px;
          border-bottom: 1px solid black ;
        }

        th {
          background-color: black ;
          color: white;
          text-align: center;
        }
        td a{
          text-decoration: none;
          background-color: #0080ff;
          color: white;
          margin: 2px;
          padding: 5px;
        }
        td a:hover{
          background-color: black;
        }
        #create_user_form td{
          color: white;
        }

        #user_table td{
          color: black;
        }
        #user_table tr:hover {
          background-color: gray ;
        }

        /* Responsive styles */
        @media only screen and (max-width: 768px) {
            table {
                font-size: 12px;
            }
            th, td {
                padding: 10px;
            }
        }



  </style>

</head>

        <!-- Navbar Start -->
          <?php include_once("../Navbar/navbar-for-register-user.php"); ?>
        <!-- Navbar End -->


             <script type="text/javascript">
                 setInterval(function(){
                  document.getElementById("message").innerHTML = "";
                      },5000);
              </script>


                <?php 
                    if(isset($_REQUEST['msg'])){
                      ?>
                      <div id="message" style="text-align: center;"><?php  echo "<h3 style='color:".$_REQUEST['color']."'>".$_REQUEST['msg']."</h3>";?> 
                      </div>
                 <?php
                     
                    }
                 ?>

     

        <!-- Add Manage-Blog File -->
        <?php   
            require_once ('manage-user.php'); 
              $users = getAllUsers(); 
        ?>
       <!-- Add Manage-Blog File  End-->

      <?php
       if(isset($_GET['user_id']))
      {
        EditFormUser("users-process.php","POST",$_GET['user_id']);
      }else{
         AddFormUser("users-process.php","POST");
      } 
      ?>

       <table id="user_table"  class="container" border="1" width="100%" >
        <tr>
          <th>User ID</th>
          <th>Role Id</th>
          <th>First Name</th>
          <th>Last Name</th>
          <th>Email</th>
          <th>Password</th>
          <th>Gender</th>
          <th>Date of Birth</th>
          <th>Image</th>
          <th>Address</th>
          <th>Is Approved</th>
          <th>Status </th>
          <th>User Status Change</th>
          <th>User Delete</th>
          <th>User Update/Edit</th>



       
        </tr>
        <?php 
          if($users->num_rows > 0)
          {
            while($user = mysqli_fetch_assoc($users))
            {
             $_SESSION['user_id'] = $user['user_id']; 
              
            ?>
            <tr>
              <td>
                <?php echo $user['user_id']; ?>   
              </td>
              <td>
                <?php echo $user['role_id']; ?>  
              
              </td>
              <td>
                <?php echo $user['first_name']; ?>
              </td>
               <td>
                <?php echo $user['last_name']; ?>
              </td>
              <td>
                <?php echo $user['email']; ?>
              </td>
               <td>
                <?php echo $user['password']; ?>
              </td>
              <td>
                <?php echo $user['gender']; ?>
              </td>
              <td>
                <?php echo $user['date_of_birth']; ?>
              </td>
             
              <td>
              <img src="<?php echo $user['user_image']; ?>" height="20%"; width="30%" >  
              </td>
              <td>
                <?php echo $user['address']; ?>
              </td>
              <td>
                <?php echo $user['is_approved']; ?>
              </td>
              <td>
                <?php echo $user['is_active']; ?>
              </td>

              <td>
                <a href="javascript:void(0)" user_id="<?php echo $user['user_id']; ?>" user_status="<?php echo $user['is_active']; ?>" onclick="statusChange(this)">
                    Status
                </a>
              </td>
                <td>
                 <a href="javascript:void(0)" user_id="<?php echo $user['user_id']; ?>" onclick="deleteUser(this)">
                Delete 
                </a> 
              </td>
              <td>
                <a href="users.php?user_id=<?php echo $user['user_id']; ?>">
                  Edit
                </a>
              </td>  
          
            </tr>
            <?php
            }

          }
          else
          {
            ?>
              <tr align="center">
                <td colspan="5">
                  No Users Available 
                </td>
              </tr>
            <?php
          }

        ?>
    </table>
    <script type="text/javascript">
    function deleteUser(obj){

       var flag = confirm("Do you want delete this record");
       if(flag)
       {
        window.location = "users-process.php?action=delete_user&user_id="+obj.getAttribute("user_id");
       }
    }

    function statusChange(obj){
      var flag = confirm("Do you want status change Active/inActive the User");
      if (flag) {
    window.location = "users-process.php?action=status_change&user_id="+ obj.getAttribute("user_id") +"&user_status="+ obj.getAttribute("user_status");

      }
    }
  </script>


</body>
</html>
