<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
  <title>Online Blogging Application</title>
    <link rel="stylesheet" type="text/css" href="jquery.dataTables.min.css">
    <script type="text/javascript" src="jquery-3.5.1.js"></script>
    <script type="text/javascript" src="jquery.dataTables.min.js"></script> 

    <script type="text/javascript">
        $(document).ready(function () {
        $('#example').DataTable();
        });
    </script>

 <style type="text/css">
    *{
      box-sizing: border-box;
    }
      input[type=submit] {
        background-color: #0080ff; 
        border: none;
        color: white;
        padding: 10px 20px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 25px;
        margin: 4px 50px;
        cursor: pointer;

      } 



 .form-group input{
   text-align: center;
   display: block;
   width: 100%;
   padding: 2px;
   margin: 16px auto;
   font-size: 25px;
   border: 5px groove #0080ff;
   border-radius: 15px;
   font-family: 'cursive;';
   color: black;
    }


    fieldset{
      margin-top: 20px;
      width: 80%;
      height: 50%;
      border-radius: 20px;
      border: 5px solid #0080ff;  
      color: white; 
    }

    table {
          border-collapse: collapse;
          margin-top: 20px;
        }

        th, td {
          padding: 15px;
          border-bottom: 1px solid black ;
        }

        th {
          background-color: black ;
          color: white;
          text-align: center;
        }
        td a{
          text-decoration: none;
          background-color: #0080ff;
          color: white;
          margin: 2px;
          padding: 5px;
        }
        td a:hover{
          background-color: black;
        }
        #table_form td{
          color: white;
        }

        #example td{
          color: black;
        }
        #example tr:hover {
          background-color: gray ;
        }




  </style>


</head>

        <!-- Navbar Start -->
           <?php include_once("../Navbar/navbar-for-register-user.php"); ?>
        <!-- Navbar End -->

          <!-- Navbar Start -->
          <?php //include_once("sidebar-for-admin.php"); ?>
        <!-- Navbar End -->


             <script type="text/javascript">
                 setInterval(function(){
                  document.getElementById("message").innerHTML = "";
                      },5000);
              </script>


                <?php 
                    if(isset($_REQUEST['msg'])){
                      ?>
                      <div id="message" style="text-align: center;"><?php  echo "<h3 style='color:".$_REQUEST['color']."'>".$_REQUEST['msg']."</h3>";?> 
                      </div>
                 <?php
                     
                    }
                 ?>

     

        <!-- Add Manage-Category File -->
        <?php   
            require_once ('manage-category.php'); 
               $categories = getAllCategory(); 
        ?>
       <!-- Add Manage-Category File  End-->

      <?php
       if(isset($_GET['category_id']))
      {
        EditFormCategory("category-process.php","POST",$_GET['category_id']);
      }else{
        AddFormCategory("category-process.php","POST");
      } 
      ?>




          <div class="col-sm-6 col-md-6 col-lg-12 ">
            
        <table id="example"  class="display" style="width:100%;">
        <thead>
            <tr>
                <th>Category ID</th>
                <th>Category Title</th>
                <th>Category Description</th>
                <th>Category Status</th>
                <th>Category Created Time</th>
                <th>Category Updated Time</th>
                <th>Category Status Change</th>
                <th>Category Delete</th>
                <th>Category Update/Edit</th>
            </tr>
        </thead>
        <tbody>

              <?php 
          if($categories->num_rows >0)
          {
            while($category = mysqli_fetch_assoc($categories))
            {
              // $_SESSION['blog_id'] = $blog['blog_id']; 
              
            ?>
            <tr>
                <td> <?php echo $category['category_id']; ?> </td>
                <td> <?php echo $category['category_title']; ?> </td>
                <td> <?php echo $category['category_description']; ?> </td>
                <td> <?php echo $category['category_status']; ?> </td>
                <td> <?php echo $category['created_at']; ?> </td>
                <td> <?php echo $category['updated_at']; ?> </td>
                <td>  
                <a href="javascript:void(0)" category_id="<?php echo $category['category_id']; ?>" category_status="<?php echo $category['category_status']; ?>" onclick="statusChange(this)">
                    Status
                </a>
              </td>
                <td>
                 <a href="javascript:void(0)" category_id="<?php echo $category['category_id']; ?>" onclick="deleteCategory(this)">
                Delete 
                </a> 
              </td>
                <td>
                <a href="category.php?category_id=<?php echo $category['category_id']; ?>">
                  Edit
                </a>
              </td>  
          
            </tr>
            <?php
            }

          }
          else
          {
            ?>
              <tr align="center">
                <td colspan="5">
                  No Category Available 
                </td>
              </tr>
            <?php
          }

        ?>
            </tr>

        </tbody>
     
    </table>
      </div>


       <?php include_once("../footer.php"); ?>

     
    <script type="text/javascript">
    function deleteCategory(obj){

       var flag = confirm("Do you want delete this record");
       if(flag)
       {
        window.location = "category-process.php?action=delete_category&category_id="+obj.getAttribute("category_id");
       }
    }

    function statusChange(obj){
      var flag = confirm("Do you want status change Active/inActive this Category");
      if (flag) {
    window.location = "category-process.php?action=status_change&category_id="+ obj.getAttribute("category_id") +"&category_status="+ obj.getAttribute("category_status");

      }
    }




  </script>


</body>
</html>
