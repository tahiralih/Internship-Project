<?php 

	require_once '../database-files/connection.php';

	function getAllCategory()
	{
		global $connection;
		$query = "SELECT * FROM category ORDER BY Category.`category_id` DESC;";
		$result = mysqli_query($connection,$query);
		return $result;
	} 
	  //Add Category
	function AddFormCategory($action ="",$method="GET")
	{ ?>

      <center>
        <fieldset class="my-5 bg-dark">
          <legend class="fw-bolder"> Create Category Here..! </legend>
            <?php 
          // echo $_SESSION['user']['first_name'];
           ?>
        
            <form method="<?php echo $method; ?>" action="<?php echo $action; ?>" enctype="multipart/form-data">  
               <table id="table_form">

                   <tr>
                    <td class="fw-bold">Category Title</td>
                    <td class="form-group" >
                      <input  type="text" name="category_title" placeholder="Enter Your Category Title" required>
                    </td>
                  </tr>

                  </tr>
                    <td class="fw-bold">Category Description</td>
                      <td class="form-group" >
                       <input  type="text" name="category_description" placeholder="Enter Your Category Title" required>
                      </td>
                  <tr>
                  
                  <tr>
                    <td class="fw-bold"> Category Status </td>
                    <td >Active <input type="radio" name="category_status" value="active" class="mx-4" required> 
                      InActive <input type="radio" name="category_status" value="inactive" class="mx-4" required>
                    </td>
                  </tr>


                    <td colspan="2" align="center">
                       <input type="submit" name="add_category" value="Create Category" >
                    </td>
                  </tr>
                  </table>
                </form>
              </fieldset>
          </center>

          <h1 class="fw-bold text-center"> Manage Category </h1>
          		<?php
	}
	 //Add Category end

  function getCategoryByCategoryId($category_id)
  {
    global $connection;
    $query = "SELECT * FROM `category` WHERE `Category`.`category_id` = $category_id";
    $res = mysqli_query($connection,$query);
    $data = mysqli_fetch_assoc($res); 
    return $data;
  }

  function EditFormCategory($action = "",$method="GET",$category_id)
  {

    $data = getCategoryByCategoryId($category_id);

    // var_dump($data);

    ?>


      <center>
        <fieldset class="my-5 bg-dark">
          <legend class="fw-bolder"> Edit Category Here..! </legend>
        
        
            <form method="<?php echo $method; ?>" action="<?php echo $action; ?>" enctype="multipart/form-data">  
            <input type="hidden" name="category_id" value="<?php echo $data['category_id'];?>">
               <table id="table_form">

                  <tr>
                    <td class="fw-bold">Category Title</td>
                      
                    <td class="form-group" >
                      <input  type="text" name="category_title" value="<?php echo $data['category_title'];?>" placeholder="Enter Your Category Title" required>
                    </td>
                  </tr>

                   <tr>
                    <td class="fw-bold">Category Description</td>
                    <td class="form-group" >
                      <input  type="text" name="category_description" value="<?php echo $data['category_description'];?>"placeholder="Enter Your Category Description" required>
                    </td>
                  </tr>                
                  
                  
                    <tr>
                       <td class="fw-bold"> Category Status </td>
                    <td >Active <input type="radio" name="category_status"  value="Active" <?php echo ($data['category_status'] == "Active")?'checked':'';?>  class="mx-4" required> 
                      InActive <input type="radio" name="category_status" value="InActive" <?php echo ($data['category_status'] == "InActive")?'checked':'';?> class="mx-4" required>
                    </td>
                  </tr>

                    <td colspan="2" align="center">
                       <input type="submit" name="update_category" value="Update Category" >
                    </td>
                  </tr>
                  </table>
                </form>
              </fieldset>
          </center>
              <?php
  }

       