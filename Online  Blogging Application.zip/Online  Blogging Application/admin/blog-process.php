<?php 
session_start(); 

	require_once("../database-files/connection.php");
	date_default_timezone_set("asia/karachi");
  	$user_admin_id= $_SESSION['user']['user_id']; //in session variable store user_id

	if(isset($_POST['add_blog']))
	{
		$folder = "Blog_Images";
		if(!is_dir($folder)){
			if(!mkdir($folder)){
			
				die;
			}
		}
		$originalname  = $_FILES['cover_image']['name'];
		$filename 	   =  rand()."_".$_FILES['cover_image']['name'];
		$temp_name 	   = $_FILES['cover_image']['tmp_name'];
		$file_path     = $folder."/".$originalname;
		

		move_uploaded_file($temp_name, $folder."/".$filename);
		extract($_POST);
		$time = date("Y-m-d h:i:s a");
		               
		$insertUserQuery = "INSERT INTO `blog`(user_id,blog_title,post_per_page,blog_background_image,blog_status,created_at,updated_at)
		VALUES(?,?,?,?,?,?,?)"; 

		$insert = mysqli_prepare($connection,$insertUserQuery);

		mysqli_stmt_bind_param($insert,'isissss',$user_admin_id,$blog_title,$post_per_page,$file_path,$status,$time,$time);

		if(mysqli_stmt_execute($insert))
		{
			$msg = "Created Blog Sucessfully ";
			header("location: blog.php?msg=$msg&color=green");	

		}
		else
		{
			$msg = "Not A Blog Created";
			header("location: blog.php?msg=$msg&color=red");
		}

	}elseif(isset($_GET['action']) && $_GET['action'] == "delete_blog")
	{
		$insert_query = "DELETE FROM blog WHERE blog_id = ?";

		$statement = mysqli_prepare($connection,$insert_query);

		mysqli_stmt_bind_param($statement,'i',$_GET['blog_id']);

		if(mysqli_stmt_execute($statement))
		{			
			
			$msg = "Blog Deleted with Blog ID :".$_GET['blog_id'];
			header("location: blog.php?msg=$msg&color=green");	

		}
		else
		{
			$msg = "Blog not delete ";
			header("location: blog.php?msg=$msg&color=red");
		}


	}


	elseif(isset($_GET['action']) && $_GET['action'] == "status_change")
	{

		if ($_GET['blog_status']== "Active") {
			$update_query = "UPDATE BLOG SET BLOG.`blog_status`='inactive' WHERE blog_id = ?";
		}
		else{
			$update_query = "UPDATE BLOG SET BLOG.`blog_status`='active' WHERE blog_id = ?";
		}

		
		
		$statement = mysqli_prepare($connection,$update_query);

		mysqli_stmt_bind_param($statement,'s',$_GET['blog_id']);

		if(mysqli_stmt_execute($statement))
		{			
			
			$msg = "Blog Status Change with Blog ID :".$_GET['blog_id'];
			header("location: blog.php?msg=$msg&color=green");	

		}
		else
		{
			$msg = "Blog not a status change ";
			header("location: blog.php?msg=$msg&color=red");
		}


	}

	if(isset($_POST['update_blog']))
	{
		$folder = "Blog_Images";
		if(!is_dir($folder)){
			if(!mkdir($folder)){
				
			}
		}
		$originalname  = $_FILES['cover_image']['name'];
		$filename 	   =  rand()."_".$_FILES['cover_image']['name'];
		$temp_name 	   = $_FILES['cover_image']['tmp_name'];
		$file_path     = $folder."/".$filename;
		

		move_uploaded_file($temp_name, $folder."/".$originalname);
		extract($_POST);
		
		$edit_query = "UPDATE `blog` SET  blog_title=?,post_per_page=?,blog_background_image=?,blog_status=? WHERE blog_id =?";


		$statmnt = mysqli_prepare($connection,$edit_query);

		mysqli_stmt_bind_param($statmnt,'sissi',$blog_title,$post_per_page,$file_path,$status,$blog_id);

		if(mysqli_stmt_execute($statmnt))
		{	
		echo $status;	
			$msg = "Blog Updated With Post ID :".$blog_id;
			header("location: blog.php?msg=$msg&color=green");	

		}
		else
		{
			$msg = "Blog not  Update";
			header("location: blog.php?msg=$msg&color=red");
		}


	}
?>