<?php 
session_start(); 

	use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\SMTP;
    use PHPMailer\PHPMailer\Exception;

    require 'PHPMailer/src/PHPMailer.php';
    require 'PHPMailer/src/SMTP.php';
    require 'PHPMailer/src/Exception.php'; 

	require_once("../database-files/connection.php");
	date_default_timezone_set("asia/karachi");
  	$user_id= $_SESSION['user_id']; //in session variable store user_id 

	if(isset($_POST['add_user']))
	{
		// print_r($_POST);
		// print_r($_FILES);
		$folder = "User_Profile";
		if(!is_dir($folder)){
			if(!mkdir($folder)){
			
				die;
			}
		}
		$originalname  = $_FILES['user_image']['name'];
		$filename 	=  rand()."_".$_FILES['user_image']['name'];
		$temp_name 	= $_FILES['user_image']['tmp_name'];
		$file_path     = $folder."/".$filename;
		

		move_uploaded_file($temp_name, $folder."/".$filename);
		extract($_POST);
		$time = date("Y-m-d h:i:s a");


		$insertUserQuery = "INSERT INTO `user`(first_name,last_name,email,password,gender,date_of_birth,user_image,address,is_active,created_at,updated_at )
		VALUES(?,?,?,?,?,?,?,?,?,?,?)"; 

		$insert = mysqli_prepare($connection,$insertUserQuery);

		mysqli_stmt_bind_param($insert,'sssssssssss',$first_name,$last_name,$email,$password,$gender,$date_of_birth,$file_path,$address,$status,$time,$time);

		$msg = "";
		if(mysqli_stmt_execute($insert))
		{
		$mail = new PHPMailer();
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->Port = 587;
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->SMTPAuth = true;
        $mail->Username = 'mr.intern11@gmail.com';
        $mail->Password = 'sqgumlcmvjtcumgt';
        $mail->setFrom('mr.intern11@gmail.com', 'Mr Admin');
        $mail->addReplyTo('mr.intern11@gmail.com', 'Admin');
        // $mail->AddCc($email);
        $mail->addAddress($email, 'User');
        $mail->Subject = 'For Create Account';
        $mail->msgHTML("Dear User your account was created on Online Blogging Application follwing details is :\n\nName: $first_name\nEmail: $email\nPassword: $password");
        $mail->send();
	
			$msg = "User Account Created Sucessfully ";
			header("location: users.php?msg=$msg&color=green");	

		}
		else
		{
			$msg = "Not a User Account Created";
			header("location: users.php?msg=$msg&color=red");
		}

	}elseif(isset($_GET['action']) && $_GET['action'] == "delete_user")
	{
			// echo $_GET['blog_id'];

		$insert_query = "DELETE FROM user WHERE user_id = ?";

		$statement = mysqli_prepare($connection,$insert_query);

		mysqli_stmt_bind_param($statement,'i',$_GET['user_id']);

		if(mysqli_stmt_execute($statement))
		{			
			
			$msg = "User Deleted with User ID :".$_GET['user_id'];
			header("location: users.php?msg=$msg&color=green");	

		}
		else
		{
			$msg = "User Record not delete ";
			header("location: users.php?msg=$msg&color=red");
		}


	}


	elseif(isset($_GET['action']) && $_GET['action'] == "status_change")
	{

		if ($_GET['user_status']== "Active") {
			$update_query = "UPDATE USER SET USER.`is_active`='INactive' WHERE user_id = ?";
		}
		else{
			$update_query = "UPDATE USER SET USER.`is_active`='Active' WHERE user_id = ?";
		}

		
		
		$statement = mysqli_prepare($connection,$update_query);

		mysqli_stmt_bind_param($statement,'s',$_GET['user_id']);

		if(mysqli_stmt_execute($statement))
		{			
			
			$msg = "User Status Change with User ID :".$_GET['user_id'];
			header("location: users.php?msg=$msg&color=green");	

		}
		else
		{
			$msg = "Users record not a status change ";
			header("location: users.php?msg=$msg&color=red");
		}


	}

	if(isset($_POST['update_user']))
	{
		$folder = "User_Profile";
		if(!is_dir($folder)){
			if(!mkdir($folder)){
				
			}
		}
		$originalname  = $_FILES['user_image']['name'];
		$filename 	=  rand()."_".$_FILES['user_image']['name'];
		$temp_name 	= $_FILES['user_image']['tmp_name'];
		$file_path     = $folder."/".$filename;
		

		move_uploaded_file($temp_name, $folder."/".$filename);
		extract($_POST);
		// print_r($_POST);
		// die();

		$edit_query = "UPDATE `user` SET  first_name=?,last_name=?,email=?,password=?,gender=?,date_of_birth=?,user_image=?,address=? WHERE user_id =?";


		$statmnt = mysqli_prepare($connection,$edit_query);

		mysqli_stmt_bind_param($statmnt,'ssssssssi',$first_name,$last_name,$email,$password,$gender,$date_of_birth,$user_image,$address,$user_id);

		if(mysqli_stmt_execute($statmnt))
		{	
		echo $status;	
			$msg = "User account Updated With User ID :".$user_id;
			header("location: users.php?msg=$msg&color=green");	

		}
		else
		{
			$msg = "user account not  Update";
			header("location: users.php?msg=$msg&color=red");
		}


	}
?>