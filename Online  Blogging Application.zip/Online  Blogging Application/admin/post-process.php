<?php
session_start();
require_once("../database-files/connection.php");
	date_default_timezone_set("asia/karachi");
  

	if(isset($_POST['add_post']))
	{
		$folder = "Post_Images";
		if(!is_dir($folder)){
			if(!mkdir($folder)){
			
				die;
			}
		}

		$originalname  = $_FILES['featured_image']['name'];
		$filename 	=  rand()."_".$_FILES['featured_image']['name'];
		$temp_name 	= $_FILES['featured_image']['tmp_name'];
		$file_path     = $folder."/".$filename;
		

		move_uploaded_file($temp_name, $folder."/".$filename);
		extract($_POST);
		$time = date("Y-m-d h:i:s a");
		               
		$insertPostQuery = "INSERT INTO `post`(blog_id,post_title,post_summary,post_description,featured_image,post_status,is_comment_allowed,created_at,updated_at)
		VALUES(?,?,?,?,?,?,?,?,?)"; 

		$insert = mysqli_prepare($connection,$insertPostQuery);

		mysqli_stmt_bind_param($insert,'isssssiss',$blog_id,$post_title,$post_summary,$post_description,$file_path,$post_status,$is_comment_allowed,$time,$time);

		$msg = "";
		if(mysqli_stmt_execute($insert))
		{
			$post_id=mysqli_insert_id($connection);

		$insertPostCategoryQuery = "INSERT INTO `post_category`(post_id,category_id,created_at,updated_at)
		VALUES(?,?,?,?)"; 
		$insert = mysqli_prepare($connection,$insertPostCategoryQuery);

		mysqli_stmt_bind_param($insert,'iiss',$post_id,$category_id,$time,$time);

		if(mysqli_stmt_execute($insert)){


		$folder = "Post-Attachment-Images";
				if(!is_dir($folder)){
					if(!mkdir($folder)){
						$message = "Folder Not Created";
						header("location:multiple_data_form.php?msg=$message&color=red");
						
					}
				}
				$image = 0;
			foreach ($_FILES['multiple_file']['name'] as $key => $value) {
				$originalname  = $_FILES['multiple_file']['name'][$key];		
				$file_name = rand().$_FILES['multiple_file']['name'][$key];		
				$temp_name = $_FILES['multiple_file']['tmp_name'][$key];


		$insertPostAQuery = "INSERT INTO `post_atachment`(post_id,post_attachment_title,post_attachment_path,created_at,updated_at)
		VALUES(?,?,?,?,?)"; 
		$insert = mysqli_prepare($connection,$insertPostAQuery );

		mysqli_stmt_bind_param($insert,'issss',$post_id,$post_attachment_title,$file_name,$time,$time);

		if(mysqli_stmt_execute($insert)){
				if(move_uploaded_file($temp_name, $folder."/".$file_name)){
					$image++;
		
	
				}
			}		
		}
		if($image > 0){
					$msg = "Created Post Sucessfully ";
			header("location: post.php?msg=$msg&color=green");	

				
			}

			
		} } 
		else
		{
			$msg = "Not A Post Created";
			header("location: post.php?msg=$msg&color=red");
		}
	}

	elseif(isset($_GET['action']) && $_GET['action'] == "delete_post")
	{
			// echo $_GET['blog_id'];

		$insert_query = "DELETE FROM post WHERE post_id = ?";

		$statement = mysqli_prepare($connection,$insert_query);

		mysqli_stmt_bind_param($statement,'i',$_GET['post_id']);

		if(mysqli_stmt_execute($statement))
		{			
			
			$msg = "Post Deleted with Post ID :".$_GET['post_id'];
			header("location: post.php?msg=$msg&color=green");	

		}
		else
		{
			$msg = "Post not delete ";
			header("location: post.php?msg=$msg&color=red");
		}


	}


	elseif(isset($_GET['action']) && $_GET['action'] == "status_change")
	{
			// echo $_GET['blog_id'];
			// echo $_GET['blog_status'];

		if ($_GET['post_status']== "Active") {
			$update_query = "UPDATE POST SET POST.`post_status`='InActive' WHERE post_id = ?";
		}
		else{
			$update_query = "UPDATE POST SET POST.`post_status`='Active' WHERE post_id = ?";
		}

		
		
		$statement = mysqli_prepare($connection,$update_query);

		mysqli_stmt_bind_param($statement,'s',$_GET['post_id']);

		if(mysqli_stmt_execute($statement))
		{			
			
			$msg = "Post Status Change with Post ID :".$_GET['post_id'];
			header("location: post.php?msg=$msg&color=green");	

		}
		else
		{
			$msg = "Post not a status change ";
			header("location: post.php?msg=$msg&color=red");
		}


	}


	if(isset($_POST['update_post']))
	{
		$folder = "Post_Images";
		if(!is_dir($folder)){
			if(!mkdir($folder)){
			
				die;
			}
		}
		$originalname  = $_FILES['featured_image']['name'];
		$filename 	=  rand()."_".$_FILES['featured_image']['name'];
		$temp_name 	= $_FILES['featured_image']['tmp_name'];
		$file_path     = $folder."/".$filename;
		

		move_uploaded_file($temp_name, $folder."/".$filename);
		extract($_POST);
		$edit_query = "UPDATE `post` SET  post_title=?,post_summary=?,post_description=?,featured_image=?,post_status=?,is_comment_allowed=? WHERE post_id =?";


		$statement = mysqli_prepare($connection,$edit_query);

		mysqli_stmt_bind_param($statement,'sssssii',$post_title,$post_summary,$post_description,$file_path,$post_status,$is_comment_allowed,$post_id);

		if(mysqli_stmt_execute($statement))
		{	
			
			$msg = "Post Updated With Post ID :".$post_id;
			header("location: post.php?msg=$msg&color=green");	

		}
		else
		{
			$msg = "Post not  Update";
			header("location: post.php?msg=$msg&color=red");
		}


	}




?>