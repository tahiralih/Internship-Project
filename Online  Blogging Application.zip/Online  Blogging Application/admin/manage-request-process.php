<?php
session_start();

	use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\SMTP;
    use PHPMailer\PHPMailer\Exception;

    require 'PHPMailer/src/PHPMailer.php';
    require 'PHPMailer/src/SMTP.php';
    require 'PHPMailer/src/Exception.php'; 
	require_once("../database-files/connection.php");
	date_default_timezone_set("asia/karachi");

if(isset($_GET['action']) && $_GET['action'] == "request_manage")
	{
		

		if ($_GET['is_approved']== "Pending") {
			$update_query = "UPDATE USER SET USER.`is_approved`='Rejected',USER.`is_active`='InActive' WHERE user.`user_id`=?;";
				
		$statement = mysqli_prepare($connection,$update_query);

		mysqli_stmt_bind_param($statement,'s',$_GET['user_id']);

		if(mysqli_stmt_execute($statement))
		{		

		$mail = new PHPMailer();
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->Port = 587;
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->SMTPAuth = true;
        $mail->Username = 'mr.intern11@gmail.com';
        $mail->Password = 'sqgumlcmvjtcumgt';
        $mail->setFrom('mr.intern11@gmail.com', 'Mr Intern');
        $mail->addReplyTo('mr.intern11@gmail.com', 'Hidaya Intern');
        $mail->AddCc('mr.intern11@gmail.com');
        $mail->AddBcc('dralih@gmail.com');
        $mail->addAddress($email, $first_name);
        $mail->Subject = 'Registration on the Online Blogging Application Plateform';
        $mail->msgHTML('Sorry Dear User!.. You have Rejected on Online Blogging Plateform ..');
        $mail->send();
			
			$msg = "User Rejected";
			header("location: manage-request.php?msg=$msg&color=green");	

		}
		else
		{
			$msg = "User not Rejected ";
			header("location: manage-request.php?msg=$msg&color=red");
		}


		}

}

if(isset($_GET['action']) && $_GET['action'] == "request_manage_for_approved")
	{
		// echo $_GET['action'];


		if ($_GET['is_approved'] == "Pending") {
			$update_query = "UPDATE USER SET USER.`is_approved`='Approved', USER.`is_active`='Active' WHERE USER.`user_id`= ?";
		

		
		 
		$statement = mysqli_prepare($connection,$update_query);

		mysqli_stmt_bind_param($statement,'s',$_GET['user_id']);

		if(mysqli_stmt_execute($statement))
		{	

		$mail = new PHPMailer();
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->Port = 587;
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->SMTPAuth = true;
        $mail->Username = 'mr.intern11@gmail.com';
        $mail->Password = 'sqgumlcmvjtcumgt';
        $mail->setFrom('mr.intern11@gmail.com', 'Mr Intern');
        $mail->addReplyTo('mr.intern11@gmail.com', 'Hidaya Intern');
        $mail->AddCc('mr.intern11@gmail.com');
        $mail->AddBcc('dralih@gmail.com');
        $mail->addAddress($email, $first_name);
        $mail->Subject = 'Registration on the Online Blogging Application Plateform';
        $mail->msgHTML('Dear User!.. You have Successfully Registered on Online Blogging Plateform and now you can easily Login..!');
        $mail->send();		
			
			$msg = "User Approved";
			header("location: manage-request.php?msg=$msg&color=green");	

		}
		else
		{
			$msg = "User not Approved ";
			header("location: manage-request.php?msg=$msg&color=red");
		}


		}

}




?>