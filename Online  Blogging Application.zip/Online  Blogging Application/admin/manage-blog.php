<?php 

	require_once '../database-files/connection.php';

	function getAllBlogs()
	{
		global $connection;
		$query = "SELECT * FROM blog ORDER BY blog.`blog_id` DESC;";
		$result = mysqli_query($connection,$query);
		return $result;
	} 
	  //Add Post
	function AddFormBlog($action ="",$method="")
	{ ?>

      <center>
        <fieldset class="my-5 bg-dark ">
          <legend class="fw-bolder"> Create Blog Here </legend>
        
            <form method="<?php echo $method; ?>" action="<?php echo $action; ?>" enctype="multipart/form-data">  
               <table id="blog_form">

                  <tr>
                    <td class="fw-bold">Blog Title</td>
                      
                    <td class="form-group" >
                      <input  type="text" name="blog_title" placeholder="Enter Your Blog Title" required>
                    </td>
                  </tr>

                   <tr>
                    <td class="fw-bold">Post Per Page</td>
                    <td class="form-group" >
                      <input  type="number" name="post_per_page" placeholder="Enter Your Post Per Page" required>
                    </td>
                  </tr>

                  </tr>
                    <td class="fw-bold">Upload a Cover Image</td>
                      <td class="form-group" >
                        <input class="text-white" type="file" name="cover_image" enctype="multipart/form-data" />
                      </td>
                  <tr>
                  
                  <tr>
                    <td class="fw-bold"> Blog Status </td>
                    <td >Active <input type="radio" name="status" value="active" class="mx-4" required> 
                      InActive <input type="radio" name="status" value="inactive" class="mx-4" required>
                    </td>
                  </tr>


                  

                    <td colspan="2" align="center">
                       <input type="submit" name="add_blog" value="Create Blog" >
                    </td>
                  </tr>
                  </table>
                </form>
              </fieldset>
          </center>

          <h1 class="fw-bold text-center"> Manage Blogs </h1>
          		<?php
	}
	 //Add Blog end

	function getBlogByBlogId($blog_id)
	{
		global $connection;
		$query = "SELECT * FROM `blog` WHERE `blog`.`blog_id` = $blog_id";
		$res = mysqli_query($connection,$query);
		$data = mysqli_fetch_assoc($res);	
		return $data;
	}

	function EditFormBlog($action = "",$method="GET",$blog_id)
	{

		$data = getBlogByBlogId($blog_id);

		?>


		  <center>
        <fieldset class="my-5 bg-dark">
          <legend class="fw-bolder"> Edit Blog Here..! </legend>
				
        
            <form method="<?php echo $method; ?>" action="<?php echo $action; ?>" enctype="multipart/form-data">  
            <input type="hidden" name="blog_id" value="<?php echo $data['blog_id'];?>">
               <table id="blog_form">

                  <tr>
                    <td class="fw-bold">Blog Title</td>
                      
                    <td class="form-group" >
                      <input  type="text" name="blog_title" value="<?php echo $data['blog_title'];?>" placeholder="Enter Your Blog Title" required>
                    </td>
                  </tr>

                   <tr>
                    <td class="fw-bold">Post Per Page</td>
                    <td class="form-group" >
                      <input  type="number" name="post_per_page" value="<?php echo $data['post_per_page'];?>"placeholder="Enter Your Post Per Page" required>
                    </td>
                  </tr>                
                  
                  </tr>
                    <td class="fw-bold">Upload a Cover Image</td>
                      <td class="form-group" >

                        <input class="text-white" type="file"  name="cover_image"  enctype="multipart/form-data"/>
                        <td><img src="<?php echo $data['blog_background_image']; ?>" width="40px" height="40px" alt="No image select"></td>
                      </td>

                  <tr>
                    <tr>
                       <td class="fw-bold"> Blog Status </td>
                    <td >Active <input type="radio" name="status"  value="Active" <?php echo ($data['blog_status'] == "Active")?'checked':'';?>  class="mx-4" required> 
                      InActive <input type="radio" name="status" value="InActive" <?php echo ($data['blog_status'] == "InActive")?'checked':'';?> class="mx-4" required>
                    </td>
                  </tr>

                    <td colspan="2" align="center">
                       <input type="submit" name="update_blog" value="Update Blog" >
                    </td>
                  </tr>
                  </table>
                </form>
              </fieldset>
          </center>
          		<?php
	}

       
	
	

?>