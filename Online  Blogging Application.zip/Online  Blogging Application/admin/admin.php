<?php
session_start();
require_once '../database-files/connection.php';
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>OnlineBloggingApplication</title>
  <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
  
</head>
<body>

    
    <!-- Navbar -->
      <?php include("../Navbar/navbar-for-register-user.php");?>   
     <!-- Navbar End -->
     
    <div class="row ">
         <div class="col-3 text-center ">
            <!-- Sidebar -->
               <?php  include_once("sidebar-for-admin.php");?>


            <!-- Sidebar -->
         </div>
    
    <!-- Manage  -->
    <div class="col-9">
        <div class="col-12">
            <div class="row">
            
        <?php  $totalUsers = "SELECT COUNT(*) AS total_users FROM user";
        $result = mysqli_query($connection, $totalUsers);
        if ($result) {
          $row = mysqli_fetch_assoc($result);
          $totalUsers = $row['total_users'];
         ?>
             <div class="col-6 text-center my-3">    
                <div class="card text-bg-dark mb-3" style="width: 100%;">
                  <div class="card-header bg-primary bg-primary">Total Users</div>
                  <div class="card-body">
                    <h5 class="card-title">Users</h5>
                   <h1 class="card-text fw-bold"><?php echo $totalUsers;?></h1>
                  </div>
                </div>
             </div>
          <?php }else {
          echo "failed ";
          }


        $pending_users = "SELECT COUNT(*) AS pending_users FROM USER WHERE user.`is_approved`='Pending' ";
        $result = mysqli_query($connection, $pending_users);
        if ($result) {
          $row = mysqli_fetch_assoc($result);
          $total_Pending_Users = $row['pending_users'];
         ?>
             <div class="col-6 text-center my-3">    
                <div class="card text-bg-dark mb-3" style="width: 100%;">
                  <div class="card-header bg-primary bg-primary">Total Pending Users</div>
                  <div class="card-body">
                    <h5 class="card-title">Pending</h5>
                   <h1 class="card-text fw-bold"><?php echo $total_Pending_Users;?></h1>
                  </div>
                </div>
             </div>
          <?php }else {
          echo "failed ";
          }
            
        $approved_users = "SELECT COUNT(*) AS approved_users FROM USER WHERE user.`is_approved`='Approved' ";
        $result = mysqli_query($connection, $approved_users);
        if ($result) {
          $row = mysqli_fetch_assoc($result);
          $total_Approved_Users = $row['approved_users'];
         ?>
             <div class="col-6 text-center my-3">    
                <div class="card text-bg-dark mb-3" style="width: 100%;">
                  <div class="card-header bg-primary bg-primary">Total Approved Users</div>
                  <div class="card-body">
                    <h5 class="card-title">Approved</h5>
                   <h1 class="card-text fw-bold"><?php echo $total_Approved_Users;?></h1>
                  </div>
                </div>
             </div>
          <?php }else {
          echo "failed ";
          }
            
        $rejected_users = "SELECT COUNT(*) AS rejected_users FROM USER WHERE user.`is_approved`='Rejected' ";
        $result = mysqli_query($connection, $rejected_users);
        if ($result) {
          $row = mysqli_fetch_assoc($result);
          $total_Rejected_Users = $row['rejected_users'];
         ?>
             <div class="col-6 text-center my-3">    
                <div class="card text-bg-dark mb-3" style="width: 100%;">
                  <div class="card-header bg-primary bg-primary">Total Rejected Users</div>
                  <div class="card-body">
                    <h5 class="card-title">Rejected</h5>
                   <h1 class="card-text fw-bold"><?php echo $total_Rejected_Users;?></h1>
                  </div>
                </div>
             </div>
          <?php }else {
          echo "failed ";
          }



        $active_users = "SELECT COUNT(*) AS active_users FROM USER WHERE user.`is_active`='Active' ";
        $result = mysqli_query($connection, $active_users);
        if ($result) {
          $row = mysqli_fetch_assoc($result);
          $total_Active_Users = $row['active_users'];
         ?>
             <div class="col-6 text-center my-3">    
                <div class="card text-bg-dark mb-3" style="width: 100%;">
                  <div class="card-header bg-primary bg-primary">Total Active Users</div>
                  <div class="card-body">
                    <h5 class="card-title">Active</h5>
                   <h1 class="card-text fw-bold"><?php echo $total_Active_Users;?></h1>
                  </div>
                </div>
             </div>
          <?php }else {
          echo "failed ";
          }

          $inactive_users = "SELECT COUNT(*) AS inactive_users FROM USER WHERE user.`is_active`='InActive' ";
        $result = mysqli_query($connection, $inactive_users);
        if ($result) {
          $row = mysqli_fetch_assoc($result);
          $total_InActive_Users = $row['inactive_users'];
         ?>
             <div class="col-6 text-center my-3">    
                <div class="card text-bg-dark mb-3" style="width: 100%;">
                  <div class="card-header bg-primary bg-primary">Total InActive Users</div>
                  <div class="card-body">
                    <h5 class="card-title">InActive</h5>
                   <h1 class="card-text fw-bold"><?php echo $total_InActive_Users;?></h1>
                  </div>
                </div>
             </div>
          <?php }else {
          echo "failed ";
          }

        $totalBlogs = "SELECT COUNT(*) AS total_blogs FROM blog";
        $result = mysqli_query($connection, $totalBlogs);
        if ($result) {
          $row = mysqli_fetch_assoc($result);
          $totalBlog = $row['total_blogs'];
         ?>
             <div class="col-6 text-center my-3">    
                <div class="card text-bg-dark mb-3" style="width: 100%;">
                  <div class="card-header bg-primary bg-primary">Total Blogs</div>
                  <div class="card-body">
                    <h5 class="card-title">Blogs</h5>
                   <h1 class="card-text fw-bold"><?php echo $totalBlog;?></h1>
                  </div>
                </div>
             </div>
          <?php }else {
          echo "failed ";
          }


        $totalPosts = "SELECT COUNT(*) AS total_posts FROM post";
        $result = mysqli_query($connection, $totalPosts);
        if ($result) {
          $row = mysqli_fetch_assoc($result);
          $totalPost = $row['total_posts'];
         ?>
             <div class="col-6 text-center my-2">    
                <div class="card text-bg-dark mb-3" style="width: 100%;">
                  <div class="card-header bg-primary">Total Posts</div>
                  <div class="card-body">
                    <h5 class="card-title">Posts</h5>
                    <h1 class="card-text fw-bold"><?php echo $totalPost;?></h1>
                  </div>
                </div>
             </div>
              <?php }else {
          echo "failed ";
          } 

        $totalCategories = "SELECT COUNT(*) AS total_categories FROM category";
        $result = mysqli_query($connection, $totalCategories);
        if ($result) {
          $row = mysqli_fetch_assoc($result);
          $totalCategories = $row['total_categories'];
         ?>
             <div class="col-6 text-center my-2">    
                <div class="card text-bg-dark mb-3" style="width: 100%;">
                  <div class="card-header bg-primary">Total Categories</div>
                  <div class="card-body">
                    <h5 class="card-title">Categories</h5>
                    <h1 class="card-text fw-bold"><?php echo $totalCategories;?></h1>
                  </div>
                </div>
             </div>
              <?php }else {
          echo "failed ";
          } 

        $totalFeedbacks = "SELECT COUNT(*) AS total_feedbacks FROM user_feedback";
        $result = mysqli_query($connection, $totalFeedbacks);
        if ($result) {
          $row = mysqli_fetch_assoc($result);
          $totalFeedbacks = $row['total_feedbacks'];
         
         ?>

              <div class="col-6 text-center my-3 ">    
                <div class="card text-bg-dark mb-3" style="width: 100%;">
                  <div class="card-header bg-primary">TotaL Feedbacks</div>
                  <div class="card-body">
                    <h5 class="card-title">Feedbacks </h5>
                    <h1 class="card-text fw-bold"><?php echo $totalFeedbacks;?></h1>
                  </div>
                </div>
             </div>
             <?php }else {
          echo "failed";
          } ?>


            </div>
        </div>
    </div>
    <!-- Manage end -->


    </div>
   
       <!-- Footer -->

        <?php 
          include_once("../footer.php");
        ?>
      <!-- Footer End -->


</body>
</html>