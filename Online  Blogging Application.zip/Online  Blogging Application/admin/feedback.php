<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>OnlineBloggingApplication</title>


 <link rel="stylesheet" type="text/css" href="jquery.dataTables.min.css">
    <script type="text/javascript" src="jquery-3.5.1.js"></script>
    <script type="text/javascript" src="jquery.dataTables.min.js"></script> 

    <script type="text/javascript">
        $(document).ready(function () {
        $('#example').DataTable();
        });
    </script>

 <style type="text/css">
    *{
      box-sizing: border-box;
    }
      input[type=submit] {
        background-color: #0080ff; 
        border: none;
        color: white;
        padding: 10px 20px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 25px;
        margin: 4px 50px;
        cursor: pointer;

      } 



 .form-group input{
   text-align: center;
   display: block;
   width: 100%;
   padding: 2px;
   margin: 16px auto;
   font-size: 25px;
   border: 5px groove #0080ff;
   border-radius: 15px;
   font-family: 'cursive;';
   color: black;
    }


    fieldset{
      margin-top: 20px;
      width: 80%;
      height: 50%;
      border-radius: 20px;
      border: 5px solid #0080ff;  
      color: white; 
    }

    table {
          border-collapse: collapse;
          margin-top: 20px;
        }

        th, td {
          padding: 15px;
          border-bottom: 1px solid black ;
        }

        th {
          background-color: black ;
          color: white;
          text-align: center;
        }
        td a{
          text-decoration: none;
          background-color: #0080ff;
          color: white;
          margin: 2px;
          padding: 5px;
        }
        td a:hover{
          background-color: black;
        }



  </style>

</head>
<body>
      <!-- Navbar Start -->
       <?php include_once("../Navbar/navbar-for-register-user.php"); ?>   
    <!-- Navbar End -->

      <br>

       <table id="example"  class="display my-2" style="width:100%;">
        <thead>
          <?php
          require_once '../database-files/connection.php';
   
          $select_query = "SELECT * FROM user_feedback"; 
          $result = mysqli_query($connection,$select_query);

            if(mysqli_num_rows($result) > 0)
            {
      
              while($row = mysqli_fetch_assoc($result))
              {

                ?> 
  
            <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Feedback</th>
            </tr>
        </thead>
        <tbody>

       
            <tr>
               <td> <?php echo $row['user_name'];?>  </td>
               <td> <?php echo $row['user_email'];?> </td>
               <td> <?php echo $row['feedback'];?>   </td>
             
          
            </tr>
                    
         
          
           
      <?php  }
            }
            else{
              echo "No feedback";
            } ?>

        </tbody>
     
    </table>



   <!-- Footer -->
        <?php 
          include_once("../footer.php");
        ?>
      <!-- Footer End -->

</body>
</html>