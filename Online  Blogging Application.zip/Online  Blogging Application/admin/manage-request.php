<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>OnlineBloggingApllication</title>
    <link rel="stylesheet" type="text/css" href="jquery.dataTables.min.css">
    <script type="text/javascript" src="jquery-3.5.1.js"></script>
    <script type="text/javascript" src="jquery.dataTables.min.js"></script> 

    <script type="text/javascript">
        $(document).ready(function () {
        $('#example').DataTable();
        });
    </script>

 <style type="text/css">
    *{
      box-sizing: border-box;
    }
      input[type=submit] {
        background-color: #0080ff; 
        border: none;
        color: white;
        padding: 10px 20px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 25px;
        margin: 4px 50px;
        cursor: pointer;

      } 



 .form-group input{
   text-align: center;
   display: block;
   width: 100%;
   padding: 2px;
   margin: 16px auto;
   font-size: 25px;
   border: 5px groove #0080ff;
   border-radius: 15px;
   font-family: 'cursive;';
   color: black;
    }


    fieldset{
      margin-top: 20px;
      width: 80%;
      height: 50%;
      border-radius: 20px;
      border: 5px solid #0080ff;  
      color: white; 
    }

    table {
          border-collapse: collapse;
          margin-top: 20px;
        }

        th, td {
          padding: 15px;
          border-bottom: 1px solid black ;
        }

        th {
          background-color: black ;
          color: white;
          text-align: center;
        }
        td a{
          text-decoration: none;
          background-color: #0080ff;
          color: white;
          margin: 2px;
          padding: 5px;
        }
        td a:hover{
          background-color: black;
        }
        #table_form td{
          color: white;
        }

        #example td{
          color: black;
        }
        #example tr:hover {
          background-color: gray ;
        }

        .btn_approve{
            background-color: #0080ff;
            color: white;
            padding: 5px;
        }
        .btn_approve:hover{
            background-color: black;

        }
        #heading{
            text-align: center;
            font-weight: bold;
            font-family: cursive;;
        }

        /* Responsive styles */
        @media only screen and (max-width: 768px) {
            table {
                font-size: 12px;
            }
            th, td {
                padding: 10px;
            }
        }



  </style>
</head>
<body>
	 <!-- Navbar Start -->
     <?php include_once("../Navbar/navbar-for-register-user.php"); ?>
    <!-- Navbar End -->


     <?php
          require_once '../database-files/connection.php';
   
          $pending_user_query = "SELECT * FROM USER  WHERE IS_APPROVED = 'Pending' AND ROLE_ID=2"; 
          $result = mysqli_query($connection,$pending_user_query);

             ?>

    <form action="manage-request-process.php" method="POST">
    <table id="example"  class="display" style="width:100%;">
        <thead>
            <h1 id="heading"> User Pending Record </h1>
            <tr>
               <th>User Full Name</th>
               <th>User Email</th>
               <th> Request </th>
               <th> Action</th>
            </tr>
        </thead>
        <tbody>

              <?php 
            if(mysqli_num_rows($result) > 0)
            {
      
              while($row = mysqli_fetch_assoc($result))
              {
              
            ?>
            <tr>
             <td><?php echo $row['first_name']." ".$row['last_name']; ?></td>
             <td><?php echo $row['email'];?></td>
             <td><?php echo $row['is_approved'];?></td>
             <td> 
                
             <a href="javascript:void(0)" user_id="<?php echo $row['user_id']; ?>" is_approved="<?php echo $row['is_approved']; ?>" onclick="requestManageForApprove(this)">
                Approve
            </a>
                
                <!-- <button class="btn_approve" name="approve" >Reject</button> -->
            <a href="javascript:void(0)" user_id="<?php echo $row['user_id']; ?>" is_approved="<?php echo $row['is_approved']; ?>" onclick="requestManage(this)">
                Rejected
            </a>


            </td>
          
            </tr>
            <?php
            }

          }
          else
          {
            ?>
              <tr align="center">
                <td colspan="5">
                  No Record in Pending 
                </td>
              </tr>
            <?php
          }

        ?>
            </tr>

        </tbody>
     
    </table>
</form>



	 <!-- Footer -->
    <?php include_once("../footer.php"); ?>
    <!-- Footer End -->

    <script type="text/javascript">
        function requestManage(obj){
      var flag = confirm("Do you want Rejected this User");
      if (flag) {
    window.location = "manage-request-process.php?action=request_manage&user_id="+ obj.getAttribute("user_id") +"&is_approved="+ obj.getAttribute("is_approved");

      }
    }
    </script>

     <script type="text/javascript">
        function requestManageForApprove(obj){
      var flag = confirm("Do you want Approve this User");
      if (flag) {
    window.location = "manage-request-process.php?action=request_manage_for_approved&user_id="+ obj.getAttribute("user_id") +"&is_approved="+ obj.getAttribute("is_approved");

      }
    }
    </script>
       

</body>
</html>
