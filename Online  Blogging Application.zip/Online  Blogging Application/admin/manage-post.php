<?php 


require_once('../database-files/connection.php');

                 

	function getAllPosts()
	{
		global $connection;
		$query = "SELECT * FROM post ORDER BY post.`post_id` DESC;";
		$result = mysqli_query($connection,$query);
		return $result;
	} 
	  //Add Post
	function AddFormPost($action ="",$method="GET")
	{ 
    global $connection; ?>

		 <!-- Add Post -->
<div class="row">
  <div class="col-12">
         
    <center>
        <fieldset class="my-5 bg-dark">
          <legend class="fw-bolder"> Create Post  Here..! </legend>
        
            <form method="<?php echo $method; ?>" action="<?php echo $action; ?>" enctype="multipart/form-data"> 
               <table id="table_form">

                  <tr>
                    <td class="fw-bold">Post Title</td>
                      
                    <td class="form-group" >
                      <input  type="text" name="post_title" required placeholder="Enter Your Post Title" >
                    </td>
                  </tr>

                   <tr>
                    <td class="fw-bold">Post Summary</td>
                    <td class="form-group" >
          
                      <textarea class="text-black" type="text" name="post_summary" required placeholder="Please write a Post Summary"  style="width:100%"></textarea>
                    </td>
                  </tr>

                  </tr>
                    <td class="fw-bold">Post Description</td>
                      <td class="form-group" >
                         <textarea class="text-black" type="text" name="post_description" required placeholder="Please write a Post Description"  style="width:100% "></textarea>
                      </td>
                  <tr>

                  </tr>
                    <td class="fw-bold">Featured Image</td>
                      <td class="form-group" >
                        <input class="text-white" type="file" name="featured_image" enctype="multipart/form-data" />
                      </td>
                  <tr>
                  
                  <tr>
                    <td class="fw-bold"> Post Status </td>
                    <td >Active <input type="radio" name="post_status"  value="active" class="mx-4" required> 
                      InActive <input type="radio" name="post_status" value="inactive" class="mx-4" required>
                    </td>
                  </tr>
                  

                 <tr>
                    <?php 
                    $get_category = "SELECT * FROM `category`;";
                      $category = mysqli_query($connection, $get_category);
                    ?>
                    <td class="fw-bold">Select Category</td>
                    <td class="form-group">
                      <div class="dropdown">
                        <select class="form-select" name="category_id">
                          <?php 
                            while ($row = mysqli_fetch_assoc($category)) 
                            { 
                          ?>
                              <option value="<?php echo $row['category_id']; ?>">
                                <?php echo $row['category_title']; ?> 
                              </option>
                             <?php  }
                          ?>

                        </select> 
                      </div>
                    </td>
                  </tr>    
                               
                 <tr>
                    <?php 
                    $get_blog = "SELECT * FROM `blog`;";
                      $blog = mysqli_query($connection, $get_blog);
                    ?>
                    <td class="fw-bold">Select Blog</td>
                    <td class="form-group">
                      <div class="dropdown">
                        <select class="form-select" name="blog_id">
                          <?php 
                            while ($row = mysqli_fetch_assoc($blog)) 
                            {
                          ?>
                              <option value="<?php echo $row['blog_id']; ?>">
                                <?php echo $row['blog_title']; ?> 
                              </option>
                             <?php  }
                          ?>

                        </select>
                      </div>
                    </td>
                  </tr>    

                  <tr>
                    <td class="fw-bold">Post Attachment Title</td>
                      
                    <td class="form-group" >
                      <input  type="text" name="post_attachment_title" required placeholder="Enter Your Post Attachment Title" >
                    </td>
                  </tr>

                  <tr>
                    <td class="fw-bold">Post Attachment File</td>
                      <td class="form-group" >
                        <input type="file" name="multiple_file[]" multiple />
                      </td>
                  </tr>

                   <tr>
                    <td class="fw-bold"> Comment Allowed </td>
                    <td >Yes <input type="radio" name="is_comment_allowed" value=1 class="mx-4" required> 
                      No <input type="radio" name="is_comment_allowed" value=0 class="mx-4" required>
                    </td>
                  </tr>

                    <td colspan="2" align="center">
                       <input type="submit" name="add_post" value="Create Post" >
                    </td>
                  </tr>
                  </table>
                </form>
              </fieldset>
          </center>

          <h1 class="fw-bold text-center"> Manage Posts </h1>
          		<?php
	}
	 //Add Blog end


	function getPostByPostId($post_id)
	{
		global $connection;
		$query = "SELECT * FROM `post` WHERE `post`.`post_id` = $post_id";
		$res = mysqli_query($connection,$query);
		$data = mysqli_fetch_assoc($res);	
		return $data;
	}

	function EditFormPost($action = "",$method="GET",$post_id)
	{

		$data = getPostByPostId('post_id');

		// var_dump($data);

		?>

			<center>
        <fieldset class="my-5 bg-dark">
          <legend class="fw-bolder"> Edit Post  Here..! </legend>
            <?php 
          // echo $_SESSION['user']['first_name'];
           ?>
        
            <form method="<?php echo $method; ?>" action="<?php echo $action; ?>" enctype="multipart/form-data"> <input type="hidden" name="post_id" value="<?php echo $data['post_id'];?>">
               <table id="table_form">

                  <tr>
                    <td class="fw-bold">Post Title</td>
                      
                    <td class="form-group" >
                      <input  type="text" name="post_title" value="<?php echo $data['post_title'];?>" required placeholder="Enter Your Post Title" >
                    </td>
                  </tr>

                   <tr>
                    <td class="fw-bold">Post Summary</td>
                    <td class="form-group" >
          
                      <textarea class="text-black" type="text" name="post_summary" value="<?php echo $data['post_summary'];?>" required placeholder="Please write a Post Summary"  style="width:100%"></textarea>
                    </td>
                  </tr>

                  </tr>
                    <td class="fw-bold">Post Description</td>
                      <td class="form-group" >
                         <textarea class="text-black" type="text" name="post_description" value="<?php echo $data['post_description'];?>" required placeholder="Please write a Post Description"  style="width:100% "></textarea>
                      </td>
                  <tr>

                  </tr>
                    <td class="fw-bold">Featured Image</td>
                      <td class="form-group" >
                        <input class="text-white" type="file" name="featured_image" enctype="multipart/form-data" />
                        <td><img src="<?php echo $data['featured_image']; ?>" width="50px" height="50px" alt="No image select"></td>
                      </td>
                  <tr>
                  

               

                   


                   <tr>
                    <td class="fw-bold"> Comment Allowed </td>
                    <td >Yes <input type="radio" name="is_comment_allowed" value=1
                     <?php echo ($data['is_comment_allowed'] == 1)?'checked':''; ?> class="mx-4" required> 
                      No <input type="radio" name="is_comment_allowed" value=0 
                      <?php echo ($data['is_comment_allowed'] == 0)?'checked':'';?>
                       class="mx-4" required>
                    </td>
                  </tr>


                    <td colspan="2" align="center">
                       <input type="submit" name="update_post" value="Update Post" >
                    </td>
                  </tr>
                  </table>
                </form>
              </fieldset>
          </center>

		
          		<?php
	}
?>
 </div>
  </div>     
	
	