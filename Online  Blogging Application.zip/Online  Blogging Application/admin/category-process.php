<?php 
//session_start(); 

	require_once("../database-files/connection.php");
	date_default_timezone_set("asia/karachi");
  	//$user_admin_id= $_SESSION['user_id']; //in session variable store user_id 

	if(isset($_POST['add_category']))
	{
		// print_r($_POST);
	
		extract($_POST);
		$time = date("Y-m-d h:i:s a");
		               
		$insertCategoryQuery = "INSERT INTO `category` (category_title,category_description,category_status,created_at,updated_at)
		VALUES(?,?,?,?,?)"; 

		$insert = mysqli_prepare($connection,$insertCategoryQuery);

		mysqli_stmt_bind_param($insert,'sssss',$category_title,$category_description,$category_status,$time,$time);

		$msg = "";
		if(mysqli_stmt_execute($insert))
		{
			$msg = "Created Category Sucessfully ";
			header("location: category.php?msg=$msg&color=green");	

		}
		else
		{
			$msg = "Not A Blog Created";
			header("location: category.php?msg=$msg&color=red");
		}

	}
	elseif(isset($_GET['action']) && $_GET['action'] == "delete_category")
	{
			// echo $_GET['blog_id'];

		$insert_query = "DELETE FROM category WHERE category_id = ?";

		$statement = mysqli_prepare($connection,$insert_query);

		mysqli_stmt_bind_param($statement,'i',$_GET['category_id']);

		if(mysqli_stmt_execute($statement))
		{			
			
			$msg = "Blog Deleted with Category ID :".$_GET['category_id'];
			header("location: category.php?msg=$msg&color=green");	

		}
		else
		{
			$msg = "Blog not delete ";
			header("location: category.php?msg=$msg&color=red");
		}


	}
	elseif(isset($_GET['action']) && $_GET['action'] == "status_change")
	{

		if ($_GET['category_status']== "Active") {
			$update_query = "UPDATE CATEGORY SET CATEGORY.`category_status`='inactive' WHERE category_id = ?";
		}
		else{
			$update_query = "UPDATE CATEGORY SET CATEGORY.`category_status`='active' WHERE category_id = ?";
		}

		
		
		$statement = mysqli_prepare($connection,$update_query);

		mysqli_stmt_bind_param($statement,'s',$_GET['category_id']);

		if(mysqli_stmt_execute($statement))
		{			
			
			$msg = "Category Status Change with Category ID :".$_GET['category_id'];
			header("location: category.php?msg=$msg&color=green");	

		}
		else
		{
			$msg = "Category not a status change ";
			header("location: category.php?msg=$msg&color=red");
		}


	}
		if(isset($_POST['update_category']))
	{
		
		extract($_POST);
	
		$edit_query = "UPDATE `category` SET  category_title=?,category_description=?,category_status=? WHERE category_id =?";


		$statement = mysqli_prepare($connection,$edit_query);

		mysqli_stmt_bind_param($statement,'sssi',$category_title,$category_description,$category_status,$category_id);

		if(mysqli_stmt_execute($statement))
		{	
			
			$msg = "Category Updated With Post ID :".$category_id;
			header("location: category.php?msg=$msg&color=green");	

		}
		else
		{
			$msg = "Category not  Update";
			header("location: category.php?msg=$msg&color=red");
		}


	}


	?>