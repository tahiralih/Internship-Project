<?php
require_once("../database-files/connection.php");
session_start();

?>

<!DOCTYPE html>
<html>
<head>
  <title>Online Blogging Application</title>
   <link rel="stylesheet" type="text/css" href="jquery.dataTables.min.css">
    <script type="text/javascript" src="jquery-3.5.1.js"></script>
    <script type="text/javascript" src="jquery.dataTables.min.js"></script> 

    <script type="text/javascript">
        $(document).ready(function () {
        $('#example').DataTable();
        });
    </script>
<style type="text/css">
     *{
      box-sizing: border-box;
    }
      input[type=submit] {
        background-color: #0080ff; 
        border: none;
        color: white;
        padding: 10px 20px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 25px;
        margin: 4px 50px;
        cursor: pointer;

      } 



 .form-group input{
   text-align: center;
   display: block;
   width: 100%;
   padding: 2px;
   margin: 16px auto;
   font-size: 25px;
   border: 5px groove #0080ff;
   border-radius: 15px;
   font-family: 'cursive;';
   color: black;
    }


    fieldset{
      margin-top: 20px;
      width: 80%;
      height: 50%;
      border-radius: 20px;
      border: 5px solid #0080ff;  
      color: white; 
    }

    table {
          border-collapse: collapse;
          margin-top: 20px;
        }

        th, td {
          padding: 15px;
          border-bottom: 1px solid black ;
        }

        th {
          background-color: black ;
          color: white;
          text-align: center;
        }
        td a{
          text-decoration: none;
          background-color: #0080ff;
          color: white;
          margin: 2px;
          padding: 5px;
        }
        td a:hover{
          background-color: black;
        }
        #table_form td{
          color: white;
        }

        #example td{
          color: black;
        }
        #example tr:hover {
          background-color: gray ;
        }

        /* Responsive styles */
        @media only screen and (max-width: 768px) {
            table {
                font-size: 12px;
            }
            th, td {
                padding: 10px;
            }
        }

  </style>

</head>

        <!-- Navbar Start -->
       <?php include_once("../Navbar/navbar-for-register-user.php"); ?>
          <!-- Navbar End -->


             <script type="text/javascript">
                 setInterval(function(){
                  document.getElementById("message").innerHTML = "";
                      },5000);
              </script>


                <?php 
                    if(isset($_REQUEST['msg'])){
                      ?>
                      <div id="message" style="text-align: center;"><?php  echo "<h3 style='color:".$_REQUEST['color']."'>".$_REQUEST['msg']."</h3>";?> 
                      </div>
                 <?php
                     
                    }
                 ?>

     

        <!-- Add Manage-Blog File -->
        <?php   
            require_once ('manage-post.php'); 
              $posts = getAllPosts(); 
        ?>
       <!-- Add Manage-Blog File  End-->

      <?php
       if(isset($_GET['post_id']))
      {
        EditFormPost("post-process.php","POST",$_GET['post_id']);
      }else{
         AddFormPost("post-process.php","POST");
      } 
      ?>
      <div class="row">
        <div class="col-12 ">
      
        <table id="example"  class="display" style="width:100%;">
         <thead>
          <tr>
            <th>Post ID</th>
            <th>Blog ID</th>
            <th>Post Title</th>
            <th>Post Summary</th>
            <th>Post Description</th>
            <th>Featured Image</th>
            <th>Post Status</th>
            <th>Comment Allowed</th>
            <th>Manage Posts Status</th>
            <th>Delete Posts</th>
            <th>Edit/Update Posts</th>
          </tr>
         </thead> 
        <?php 
          if($posts->num_rows > 0)
          {
            while($post = mysqli_fetch_assoc($posts))
            {
              $_SESSION['blog_id'] = $post['blog_id']; 
              
            ?>
            <tr>
              <td>
               <?php echo $post['post_id']; ?>   
              </td>
              <td>
                <?php echo $post['blog_id']; ?>   
              </td>
      
              <td>
                <?php echo $post['post_title']; ?>
              </td>
              <td>
                <?php echo $post['post_summary']; ?>
              </td>
              <td>
                <?php echo $post['post_description']; ?>
              </td>
              <td>
              <img src="<?php echo $post['featured_image']; ?>"  height="50%"; width="50%";>  
              </td>
              <td>
                <?php echo $post['post_status']; ?>
              </td>
               <td>
                <?php 
                  if ($post['is_comment_allowed']== 1) {
                    echo "Yes"; 
                  }else
                  {
                    echo "No";
                  }
                 ?>
              </td>
              <td>
                <a href="javascript:void(0)" post_id="<?php echo $post['post_id']; ?>" post_status="<?php echo $post['post_status']; ?>" onclick="statusChange(this)">
                    Status
                </a>
              </td>

                <td>
                 <a href="javascript:void(0)" post_id="<?php echo $post['post_id']; ?>" onclick="deletePost(this)">
                Delete 
                </a> 
                </td>
                <td>
                <a href="post.php?post_id=<?php echo $post['post_id']; ?>">
                  Edit
                </a>
              </td>  
          
            </tr>
            <?php
            }

          }
          else
          {
            ?>
              <tr align="center">
                <td colspan="5">
                  No Posts Available 
                </td>
              </tr>
            <?php
          }

        ?>
    </table>

        </div>
      </div>
    <script type="text/javascript">
    function deletePost(obj){

       var flag = confirm("Do you want delete this record");
       if(flag)
       {
        window.location = "post-process.php?action=delete_post&post_id="+obj.getAttribute("post_id");
       }
    }

    function statusChange(obj){
      var flag = confirm("Do you want status change Active/inActive this Blog");
      if (flag) {
    window.location = "post-process.php?action=status_change&post_id="+ obj.getAttribute("post_id") +"&post_status="+ obj.getAttribute("post_status");

      }
    }
  </script>




</body>
</html>
