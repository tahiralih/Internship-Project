
<style type="text/css">
	th{
		background-color: blue;
		color: white;
	}
</style>

<?php

if (isset($_REQUEST['register'])) {

	extract($_REQUEST);

	$flag = true;
	$error_msg = null;

	if ($first_name == "") {
		$flag = false;
		$error_msg.="<li>Please Enter First Name !...</li>";
	}else{

		if( !preg_match($alphabet_pattern, $first_name) ){
			$flag = false;
		    $error_msg.="<li>First Name must be like eg : Sherry !...</li>";
		}
	}


	if ($last_name == "") {
		$flag = false;
		$error_msg.="<li>Please Enter Last Name !...</li>";
	}else{

		if( !preg_match($alphabet_pattern, $last_name) ){
			$flag = false;
		    $error_msg.="<li>Last Name must be like eg : Wilson !...</li>";
		}
	}

	if ($email == "") {
		$flag = false;
		$error_msg.="<li>Please Enter Email !...</li>";
	}else{

		if( !preg_match($email_pattern, $email) ){
			$flag = false;
		    $error_msg.="<li>Email must be like eg : sherry1@yahoo.com !...</li>";
		}
	}

	if (!isset($gender)) {
		$flag = false;
		    $error_msg.="<li>Please Select Gender !...</li>";
	}

	

	


	if ($flag == false) {
		
		header("location:client_side_validation.php?message=".$error_msg);
	}else{?>

          <table border="2" style="width: 100%;height: 100px;text-align: center;background-color: lightblue">
          	<tr>
          		<th>First Name</th>
          		<?php echo $middle_name?"<th>Middle Name</th>":""; ?>
          		<th>Last Name</th>
          		<th>Email</th>
          		<th>Gender</th>
          		<th>CNIC</th>
          		<th>Phone Number</th>
          		<th>Country</th>
          		<th>Policies</th>
          	</tr>
          	<tr>
          		<td><?php echo $first_name; ?></td>
          		<?php echo $middle_name?"<td>$middle_name</td>":""; ?>
          		<td><?php echo $last_name; ?></td>
          		<td><?php echo $email; ?></td>
          		<td><?php echo $gender; ?></td>
          		<td><?php echo $cnic; ?></td>
          		<td><?php echo $phone_number; ?></td>
          		<td><?php echo $country; ?></td>
          		<td><?php echo $policies[0]."<br/>".$policies[1]."<br/>".$policies[2]."<br/>".$policies[3]; ?></td>
          	</tr>
          </table>
	<?php }
}


?>