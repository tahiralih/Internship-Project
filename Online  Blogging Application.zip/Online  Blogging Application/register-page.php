<?php 

include_once("database-files/connection.php");
?>
<!DOCTYPE html>
<html>
<head>
	<title>Registration</title>
	<style type="text/css">
		*{
			box-sizing: border-box;	

		}
		
		body{
			background-image: url("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ00U1W_4q88vajgQUdiXnr21vooMCRzohjdnRPPCXjc11tchvWXia4m_25wxUq98CwLxQ&usqp=CAU");
			background-repeat: no-repeat;
			background-size: cover;

		}
		fieldset{
			margin-top: 20px;
			width: 50%;
			height: 60%;
			border-radius: 20px;
			border: 5px solid black;
			background-color: black;
			color: white;
			
		}
		table{
		height: 400px;
		}
		table tr td{
			font-weight: bolder;
		}
		input{
			padding: 10px;
			font-weight: bolder;
		}
		span{
			color: red;
		}

		li{
			color: red;
			list-style: none;
		}
	</style>


	
</head>
<body>

		<!-- Navbar Start -->
          <?php include_once("navbar.php"); ?>
         <!-- Navbar End -->
<script type="text/javascript">
		function register_form(){ 
			// <a href="pdf/register-data.php"></a>
			var alphabet_pattern = /^[A-Z]{1}[a-z]{2,}$/;
			var email_pattern = /^[a-z]{2,30}[0-9]{1,5}[@][a-z]{3,10}[.][a-z]{1,8}$/;
			var password_pattern = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,20}$/;
			var address_pattern = /^[A-Z][a-z]{1,}$/;
			var first_name = document.getElementById("first_name").value;
			var last_name = document.getElementById("last_name").value;
			var password = document.getElementById("password").value;
			var email = document.getElementById("email").value;
			var gender = null;
			var male = document.getElementById("gender_male");
			var female = document.getElementById("gender_female");

			if (male.checked) {
			gender = male.value;
			}
			else if (female.checked) {
			gender = female.value;
			}
			var date_of_birth = document.getElementById("date_of_birth").value;
			var address = document.getElementById("address").value;
			var image = document.getElementById("image").value;
			



		var flag = true;


		if (first_name == "") {
            flag = false;
            document.getElementById("first_name_msg").innerHTML = "Please Enter First Name !...";
		}
		else
		{
			document.getElementById("first_name_msg").innerHTML = "";

             if (alphabet_pattern.test(first_name) == false) {
             	flag = false;
            document.getElementById("first_name_msg").innerHTML = " First Name must be like eg: Tahir";
             }  
		}



		if (last_name == "") {
            flag = false;
            document.getElementById("last_name_msg").innerHTML = "Please Enter Last Name !...";
		}
		else
		{
			document.getElementById("last_name_msg").innerHTML = "";

             if (alphabet_pattern.test(last_name) == false) {
             	flag = false;
            document.getElementById("last_name_msg").innerHTML = " Last Name must be like eg: Hingoro";
             }  
		}


		if (password == "") {
            flag = false;
            document.getElementById("password_msg").innerHTML = "Please Enter the Password ...";
		}
		else
		{
			document.getElementById("password_msg").innerHTML = "";

             if (password_pattern.test(password) == false) {
             	flag = false;
            document.getElementById("password_msg").innerHTML = "password between 7 to 15 characters one numeric digit and a special character e.g Tahir/1";
             }  
		}




		if (email == "") {
            flag = false;
            document.getElementById("email_msg").innerHTML = "Please Enter the Email !...";
		}
		else
		{
			document.getElementById("email_msg").innerHTML = "";

             if (email_pattern.test(email) == false) {
             	flag = false;
            document.getElementById("email_msg").innerHTML = " Email must be like eg:tahirali12@gmail.com ";
             }  
		}


		if (!gender) {

			flag = false;
            document.getElementById("gender_msg").innerHTML = "Please Select Gender !...";
		}else{
			document.getElementById("gender_msg").innerHTML = "";
		}

		if (!date_of_birth) {
				flag = false;
            document.getElementById("date_of_birth_msg").innerHTML = "Please Select the Date of Birth !...";
		}else{
			 document.getElementById("date_of_birth_msg").innerHTML = "";
		}

		if (!image) {
				flag = false;
            document.getElementById("image_msg").innerHTML = "Please Select the Image !...";
		}else{
			 document.getElementById("image_msg").innerHTML = "";
		}


			if (address == "") {
            flag = false;
            document.getElementById("address_msg").innerHTML = "Please Enter the Address !...";
		}
		else
		{
			document.getElementById("address_msg").innerHTML = "";

             if (address_pattern.test(address) == false) {
             	flag = false;
            document.getElementById("address_msg").innerHTML = "Please Address must be like eg: Hyderabad";
             }  
		}
		
		

				

			if (flag) {
          	return true;
         	}
         	 else
         	{
			return false;
            }



			// return false;
		}

	</script>

<center>

		
	
	<fieldset>

	
	<form method="POST" action="register-form-process.php"  enctype="multipart/form-data">  
<table >
	<tr>
						<?php if (isset($_REQUEST['message'])) {
							      echo "<ul>";
							       echo $_REQUEST['message'];
							      echo "</ul>";
						} ?>
	</tr>
	<h1 class="my-3 ">REGISTRATION FORM </h1>
			<?php 
					if(isset($_REQUEST['msg'])){
						echo "<h3 style='color:".$_REQUEST['color']."'>".$_REQUEST['msg']."</h3>";
					}
				?>
					
	<tr>
		<td>First Name <span>*</span></td>
		<td><input type="text" name="first_name" placeholder="Enter Your First Name" id="first_name">
		<span id="first_name_msg"></span>
		</td>
	</tr>

	<tr>
		<td>Last Name <span>*</span></td>
		<td><input type="text" name="last_name" placeholder="Enter Your Last Name" id="last_name">
		<span id="last_name_msg"></span>
		</td>
	</tr>

	<tr>
		<td>Password <span>*</span></td>
		<td><input type="text" name="password" placeholder="Enter Your Password" id="password" >
		<span id="password_msg"></span>
		</td>
	</tr>

	<tr>
		<td>Email <span>*</span></td>
		<td><input type="text" name="email" placeholder="Enter Your Email" id="email">
		<span id="email_msg"></span>
		</td>
	</tr>



	<tr>
		<td>Gender <span>*</span></td>
		<td>Male <input type="radio" name="gender" value="male" id="gender_male"> 
			Female <input type="radio" name="gender" value="female" id="gender_female">
		<span id="gender_msg" ></span>
		</td>
	</tr>

					
	<tr>
		<td>Date of Birth <span>*</span></td>
		<td><input type="date" name="date_of_birth" id="date_of_birth"> 
		<span id="date_of_birth_msg"></span>
		</td>
	</tr>

	<tr>
		<td>Address <span>*</span></td>
		<td> <textarea name="address" id="address"></textarea>
		<span id="address_msg"></span>
		</td>
	</tr>

	
	<tr>
		<td>Upload your profile picture <span>*</span></td>
			<td >
				<input type="file" name="user_image" id="image" enctype="multipart/form-data" />
				<span id="image_msg"></span>
			</td>
	</tr>

	<tr>
		<td colspan="2" align="center">
			<input type="submit" name="register" value="Register" onclick="return register_form()"></input>
		</td>
			
	</tr>
</table>
</form>
</fieldset>
</center>
				


    <!-- Login  -->
      <?php include_once("login-page.php"); ?>
         <!-- Login End -->
         
          <!-- Footer -->
        <?php 
          include_once("footer.php");
        ?>
      <!-- Footer End -->
</body>
</html>



