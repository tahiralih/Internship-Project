<?php
session_start();

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>ProfileEidt</title>
<style type="text/css">

  body {
  background: white;
}

.form-control:focus {
  box-shadow: none;
  border-color: black;
}

.profile-button {
  background: #0080ff;
  box-shadow: none;
  border: none;
  padding: 5px;
}

.profile-button:hover {
  background: gray;
  color: black;
}

.profile-button:focus {
  background: gray;
  box-shadow: none;
}

.profile-button:active {
  background: green;
  box-shadow: none;
}

.back:hover {
  color: #0080ff;
  cursor: pointer;
}
#editbtn{
  color: white;
  text-decoration: none;
  background: #0080ff;
  box-shadow: none;
  border: none;
  padding: 5px;
}
#editbtn:hover{
  background-color: gray;
}
#backtohome{
  color: white;
  text-decoration: none;
  background: #0080ff;
  box-shadow: none;
  border: none;
  padding: 5px;
}
#backtohome:hover{
  background-color: gray;

}

</style>
	
</head>
<body>
    <!-- Navbar  -->
      <?php include_once("../Navbar/navbar-for-register-user.php"); ?>
    <!-- Navbar End -->

    <?php
    require_once '../database-files/connection.php';
    require_once ('user-profile-manage.php'); 
      
       if(isset($_GET['user_id']))
      {
       EditProfile("user-edit-profile-process.php","POST",$_GET['user_id']);
      }else{
        profileData();
      }  
      

function ProfileData(){
  global $connection;
    $user_id= $_SESSION['user']['user_id'];
    $select_query = "SELECT * FROM USER WHERE USER.`user_id`=$user_id;"; 
            $result = mysqli_query($connection,$select_query);

            if(mysqli_num_rows($result) > 0)
            {
      
              while($row = mysqli_fetch_assoc($result))
            {?>            
  
        <div class="container rounded text-white mt-5 " style="background-color: black; color: black; height: 50%;">
                <div class="row">

                  <script type="text/javascript">
                 setInterval(function(){
                  document.getElementById("message").innerHTML = "";
                      },5000);
              </script>


                <?php 
                    if(isset($_REQUEST['msg'])){
                      ?>
                      <div id="message" style="text-align: center;"><?php  echo "<h3 style='color:".$_REQUEST['color']."'>".$_REQUEST['msg']."</h3>";?> 
                      </div>
                 <?php
                     
                    } ?>


                    <div class="col-md-4 border-right">
                        <div class="d-flex flex-column align-items-center text-center p-3 py-5"><img class="rounded-circle mt-5" src="../<?php echo $row['user_image'];?>" alt="No Image" width="90"><span class="font-weight-bold"><?php echo $row['first_name']." ".$row['last_name'];?></span><span class="text-white-50"><?php echo $row['email'];?></span></div>
                    </div>
                    <div class="col-md-8">
                        <div class="p-3 py-5">
                            <div class="d-flex justify-content-between align-items-center mb-3 my-3">
                                <div class="d-flex flex-row align-items-center back"><i class="fa fa-long-arrow-left mr-1 mb-1"></i>
                                  <a href="register-user-dashboard.php"  id="backtohome"> <h6>Back to home</h6></a>
                                   
                                </div>

                                 <a id="editbtn" href="user-edit-profile.php?user_id=<?php echo $row['user_id']; ?>">
                                 Edit Profile
                                </a>
                               
                            </div>
                            <div class="row mt-2 ">
                                <div class="col-md-6 ">First Name<input type="text" class="form-control" value="<?php echo $row['first_name'];?>" placeholder="first name" readonly></div>
                                <div class="col-md-6">Last Name<input type="text" class="form-control" value="<?php echo$row['last_name'];?>"  placeholder="Last Name" readonly></div>
                            </div>
                            <div class="row mt-3">
                                <div class="col-md-12">Email<input type="text" value="<?php echo $row['email'];?>" class="form-control" placeholder="Email" readonly></div>
                            </div>
                                 <div class="row mt-3">
                                <div class="col-md-6 ">Gender
                                  Male<input type="radio" name="gender" value="Male" <?php echo ($row['gender'] == "Male")?'checked':'';?> readonly >
                                  Female<input type="radio" name="gender" value="Female" <?php echo ($row['gender'] == "Female")?'checked':'';?> readonly>
                                </div>
                                <div class="col-md-6 "> Date of Birth: <input type="date" value="<?php echo $row['date_of_birth']; ?>" readonly> </div>
                            </div>
                            <div class="row mt-3">
                                <div class="col-md-12">Address<textarea type="text" class="form-control" readonly> <?php echo $row['address']; ?> </textarea>
                                </div>
                            </div>
                          
                            <div class="mt-5 text-right"><button class="btn btn-primary profile-button" type="button">Save Profile</button></div>
                        </div>
                    </div>
                </div>
            </div>

          ?>
          <?php
                 }
            }
            else{
                 echo "No Posts";
           }
                    
} //function end ?>

   

</body>
</html>