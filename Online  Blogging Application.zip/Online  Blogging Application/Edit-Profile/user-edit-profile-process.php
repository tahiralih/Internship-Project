<?php
    
 require_once '../database-files/connection.php';
 date_default_timezone_set("asia/karachi");
if(isset($_POST['update_user_data']))
	{
		extract($_POST);
		
        $time = date("Y-m-d h:i:s a"); 

		$update_query = "UPDATE `user` SET  first_name =?, last_name=?,  gender=?, date_of_birth=?, address=?,updated_at=? WHERE user_id =?";

		$statement = mysqli_prepare($connection,$update_query);

		mysqli_stmt_bind_param($statement,'ssssssi', $first_name, $last_name,$gender, $date_of_birth, $address,$time, $user_id);

		if(mysqli_stmt_execute($statement))

		{			
			
			$msg = "Profile Data Updated Successfully :";
			header("location: user-edit-profile.php?msg=$msg&color=green");	
		}
		else
		{
			$msg = "Profile data not Updated ";
			header("location: user-edit-profile.php?msg=$msg&color=red");
		}


	}


?>
