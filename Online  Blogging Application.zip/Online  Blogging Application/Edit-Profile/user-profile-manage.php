<?php

      
  function EditProfile($action = "",$method="GET",$user_id){
    global $connection;
    $user_id= $_SESSION['user']['user_id'];
    $select_query = "SELECT * FROM USER WHERE USER.`user_id`=$user_id;"; 
            $result = mysqli_query($connection,$select_query);

            if(mysqli_num_rows($result) > 0)
            {
      
              while($row = mysqli_fetch_assoc($result))
            {?>            
         <form method="<?php echo $method; ?>" action="<?php echo $action; ?>" enctype="multipart/form-data">  
            <input type="hidden" name="user_id" value="<?php echo $row['user_id'];?>">
        <div class="container rounded text-white mt-5 " style="background-color: black; color: black; height: 50%;">
                <div class="row">
                    <div class="col-md-4 border-right">
                        <div class="d-flex flex-column align-items-center text-center p-3 py-5"><img class="rounded-circle mt-5" src="../<?php echo $row['user_image'];?>" alt="No Image" width="90"><span class="font-weight-bold"><?php echo $row['first_name']." ".$row['last_name'];?></span><span class="text-white-50"><?php echo $row['email'];?></span></div>
                    </div>
                    <div class="col-md-8">
                        <div class="p-3 py-5">
                            <div class="d-flex justify-content-between align-items-center mb-3 my-3">
                                <div class="d-flex flex-row align-items-center back"><i class="fa fa-long-arrow-left mr-1 mb-1"></i>
                                  <a id="backtohome" href="user-edit-profile.php" style="color: white; text-decoration: none; "> <h6>Back to home</h6></a>
                                   
                                </div>

                                <a href="#" style="text-decoration: none;"> <h6 class="text-right text-white" >Edit Profile</h6></a>
                               
                            </div>
                            <div class="row mt-2 ">
                                <div class="col-md-6 ">First Name<input type="text" name="first_name" class="form-control" value="<?php echo $row['first_name'];?>" placeholder="first name"></div>
                                <div class="col-md-6">Last Name<input type="text" name="last_name" class="form-control" value="<?php echo$row['last_name'];?>"  placeholder="Last Name" ></div>
                            </div>
                            <div class="row mt-3">
                                <div class="col-md-12">Email<input type="text" name="email" readonly value="<?php echo $row['email'];?>" class="form-control" placeholder="Email"></div>
                            </div>
                                 <div class="row mt-3">
                                <div class="col-md-6 ">Gender
                                  Male<input type="radio" name="gender" value="Male" <?php echo ($row['gender'] == "Male")?'checked':'';?>  >
                                  Female<input type="radio" name="gender" value="Female" <?php echo ($row['gender'] == "Female")?'checked':'';?> >
                                </div>
                                <div class="col-md-6 "> Date of Birth: <input type="date" name="date_of_birth" value="<?php echo $row['date_of_birth']; ?>" > </div>
                            </div>
                            <div class="row mt-3">
                                <div class="col-md-12">Address<textarea type="text" name="address" class="form-control"> <?php echo $row['address']; ?> </textarea>
                                </div>
                            </div>
                          
                            <div class="mt-5 text-right">
                            <input class="profile-button text-white" type="submit" name="update_user_data" value="Update Profile Data" >  
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            </form>

          ?>
          <?php
                 }
            }
            else{
                 echo "No Posts";
           }
                    
}//function end
          ?>
