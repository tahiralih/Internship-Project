 <!DOCTYPE html>
 <html>
 <head>
   <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <title>OnlineBloggingApplication</title>
        <style type="text/css">
              .comment-section {
            margin-top: 50px;
          }

          .comment {
            margin-bottom: 20px;
            border: 1px solid #ddd;
            padding: 10px;
          }

          .comment-header {
            display: flex;
            align-items: center;
            margin-bottom: 10px;
          }

          .comment-header img {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            margin-right: 10px;
          }

          .comment-header h4 {
            margin: 0;
          }

          .comment-header .date {
            margin-left: auto;
          }

          .comment-body {
            margin: 0;
          }

          .comment-form {
            margin-top: 50px;
          }

          .comment-form h3 {
            margin-bottom: 20px;
          }

          .form-group {
            margin-bottom: 20px;
          }

          label {
            display: block;
            margin-bottom: 5px;
          }

          input,
          textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
          }

          button[type="submit"] {
            background-color: #0080ff;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
          }

          button[type="submit"]:hover {
            background-color: #0052cc;
          }
          #commentbtn{
            display: block;
            float: right;
          }
           #commentbtn:hover{
            background-color: black;

          }
          </style>
 </head>
 <body>

 
     
        <!-- Comment Code -->
        <div class="comment-section">
            <h3 style="text-align: left;">Comments</h3>
            <div class="comment">
              <div class="comment-header">
                <img src="images/a.jpg" alt="Profile Picture" />
                <h4>Tahir Ali</h4>
                <p class="date">May 5, 2023</p>
              </div>
              <div class="comment-body">
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
              </div>
            </div>
           
          <div >
                <h2>Comment:</h2>
                <textarea id="comment" name="comment" required></textarea>
              </div>
              <a href=""><button id="commentbtn" type="submit">Comment</button></a>
               
          </div>
        <!-- comment end -->


  </body>
 </html>