     <!DOCTYPE html>
     <html>
     <head>
       <meta charset="utf-8">
       <meta name="viewport" content="width=device-width, initial-scale=1">
       <title>OnlineBloggingApplication</title>
     </head>
     <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
     <body>
     

     <!-- Navbar Start -->
    <nav class="navbar navbar-expand-lg  sticky-top" style="background-color: #0080ff;">
        <div class="container-fluid">
          <img src="images/logo.png" alt="" width="80px">
          <a class="navbar-brand text-white " href="#"><b>ONLINE BLOGGING APPLICATION</b></a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarScroll" aria-controls="navbarScroll" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarScroll">
            <ul class="navbar-nav me-auto my-2 my-lg-0 navbar-nav-scroll" style="--bs-scroll-height: 100px;">
              <li class="nav-item">
                <a class="nav-link active text-white" aria-current="page" href="home-page.php">Home</a>
              </li>

              <li class="nav-item">
                <a class="nav-link text-white" href="#about_us">About Us</a>
              </li>
              <li class="nav-item">
                <a class="nav-link text-white" href="#contact_us">Contact Us</a>
              </li>
               <?php
            require_once 'database-files/connection.php';
                      $get_blog = "SELECT * FROM `blog`;";
                      $blog = mysqli_query($connection, $get_blog);
                    ?>

                    <li class="nav-item dropdown ">
                        <a class="nav-link dropdown-toggle text-white" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Blogs
                        </a>
                        <ul class="dropdown-menu  bg-primary text-black">
                              <?php 
                                    while ($row = mysqli_fetch_assoc($blog)) 
                                    {
                                        ?><li><a class="dropdown-item text-black" href="blog-for-home.php?blog_id=<?php echo $row['blog_id']; ?>" >
                                            <?php echo $row['blog_title']; ?> 
                                        </a></li>
                    
                                        <?php   
                                    }

                                ?>
                        </ul>
                    </li> 

                     <?php
                      $get_category= "SELECT * FROM `category`;";
                      $category = mysqli_query($connection, $get_category);
                    ?>

                    <li class="nav-item dropdown ">
                        <a class="nav-link dropdown-toggle text-white" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Category
                        </a>
                        <ul class="dropdown-menu  bg-primary text-black">
                              <?php 
                                    while ($row = mysqli_fetch_assoc($category)) 
                                    {
                                        ?><li><a class="dropdown-item text-black" href="category.php?category_id=<?php echo $row['category_id']; ?>" >
                                            <?php echo $row['category_title']; ?> 
                                        </a></li>
                    
                                        <?php   
                                    }

                                ?>
                        </ul>
                    </li> 
                      
                  
  
            </ul>
             

           
               <button class="btn text-white" type="submit" data-bs-toggle="modal" data-bs-target="#staticBackdropLogin">Login</button>
               <a href="register-page.php"> <button class="btn text-white" type="submit"  data-bs-target="#staticBackdropRegister">Register</button></a>
             
  
          </div>
        </div>
    </nav>

<script type="text/javascript" src="bootstrap/js/bootstrap.bundle.min.js"></script>

         </body>
     </html>

  <!-- Navbar End -->