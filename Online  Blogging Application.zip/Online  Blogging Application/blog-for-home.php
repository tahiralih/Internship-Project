<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>OnlineBloggingApplication</title>

 

</head>
<body>
     
          
        <!-- Navbar  -->
      <?php include_once("navbar.php"); ?>
         <!-- Navbar End -->

         <!-- Login  -->
      <?php include_once("login-page.php"); ?>
         <!--  End -->
         <?php
              $blog_id=$_GET['blog_id'];
              require 'database-files/connection.php';
              $select_query_for_blog = "SELECT  BLOG.`blog_id`, BLOG.`blog_title`, BLOG.`blog_background_image`,POST.`post_id`
              FROM POST 
              INNER JOIN BLOG
              ON BLOG.`blog_id`=POST.`blog_id`
              WHERE BLOG.`blog_status`='Active' AND BLOG.`blog_id`= $blog_id;"; 
            $result = mysqli_query($connection,$select_query_for_blog);

            if(mysqli_num_rows($result) > 0)
            {
      
              $row = mysqli_fetch_assoc($result)
        
                    
                    // echo $row['blog_background_image']; 
                 ?>

  <!-- Cover Image -->
 <div class="card">
 
  <img src="admin/<?php  echo $row['blog_background_image'];  ?>" class="card-img-bottom" alt="No Cover Image" height="400px">
</div>

  <!-- Cover Image End-->

   <!-- Blog Name -->
           <div class="row">
                <div class="col  m-2 fw-bold ">
                   <h2 class="text-uppercase fw-bolder" style="text-decoration-thickness:5px; text-decoration-color: #F6B608 ;  text-underline-offset:15px; color: black; text-align: left;" id="about_us_heading"> <?php  echo $row['blog_title'];  ?></h2>  
                <div>
            </div>
        <?php   
               }
              else{
                echo "No Blogs";
              }
              ?>
    <!-- Blog Name End-->
      <!-- 2 Column Layout -->
      <div class="row ">
        <!-- First Column -->
         <div class="col-9  text-center p-2 fw-bolder ">
           <?php
           $select_query_for_post = "SELECT  BLOG.`blog_id`, BLOG.`blog_title`, BLOG.`blog_background_image`,POST.`post_title`,POST.`post_status`,POST.`featured_image`,POST.`post_id`,
               POST.`created_at`,POST.`updated_at`, POST.`post_summary`,POST.`post_description`,CATEGORY.`category_title`, CATEGORY.`category_description`
              FROM POST 
              INNER JOIN BLOG
              ON BLOG.`blog_id`=POST.`blog_id`
              INNER JOIN POST_CATEGORY
              ON POST.`post_id`=POST_CATEGORY.`post_id`
              INNER JOIN CATEGORY
              ON POST_CATEGORY.`category_id`=CATEGORY.`category_id`
              WHERE POST.`post_status`='Active' AND POST.`blog_id`=$blog_id
              ORDER BY POST.`updated_at` DESC;";  
            $result = mysqli_query($connection,$select_query_for_post);

            if(mysqli_num_rows($result) > 0)
            {   
            while ($row= mysqli_fetch_assoc($result)) {     
            ?>
            <!-- Post  -->
              <div class="container">
               <div class="card mb-3" style="max-width: 100%;">
                  <div class="row g-0">
                   
                     <div class="col-md-4">
                        <img src="admin/<?php echo $row['featured_image'];  ?>" class="img-fluid rounded-start" alt="No Posts Image" width="100%" height="100%"> 
                     </div>
                    <div class="col-md-8">
                      <div class="card-body">
                        <div class="row">
                         
                          <h5 class="card-title"><?php echo $row['post_title'];  ?></h5>
                        </div>
                        
                        <p class="card-text"><?php echo $row['post_summary'];  ?></p>
                        <p class="card-text"><small class="text-body-secondary"></small></p>
                            <a href="post-readmore-page.php?post_id=<?php echo $row['post_id'];?>" class="btn btn-primary" >Read More</a>
                       </div>
                      </div>
                    </div>

                 </div>
              </div>
              <?php
            }}
                else{
                echo "No Posts";
              }
              ?>
            <!-- Post End -->
               

          </div>
              <!-- First Column End -->
         

         <div class="col-3 text-center p-2 fw-bolder ">
          <!-- Second Column -->

          <!--Recent News  -->
            <?php  include("recent-news.php"); ?>
           <!-- Recent News -->
          
         </div>
         <!-- Second Column End -->
       
          <div class="col-12 text-center p-2 fw-bolder ">
            
              <!-- About Us -->
                <?php include_once("about-us.php"); ?>
              <!-- About us End -->
             

              <div class="col-12 text-white bg-dark my-3">
              <!-- Contact us -->
               <?php  include_once("contact-us.php"); ?>
              <!-- Contact us End-->
              </div>

            </div>


    </div>
    <!-- 2Column Layout End-->



      <!-- Footer -->
        <?php 
          include_once("footer.php");
        ?>
      <!-- Footer End -->


</body>
</html>