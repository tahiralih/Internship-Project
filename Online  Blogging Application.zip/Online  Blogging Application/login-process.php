<?php
session_start();
	
include_once("database-files/connection.php");
	if(isset($_POST['login']))
	{
			extract($_POST);
			$login_query = "SELECT * FROM `user` 
			WHERE `user`.`email` = ?
			AND `user`.`password` = ?";

			$statement = mysqli_prepare($connection,$login_query);

			mysqli_stmt_bind_param($statement,"ss",$email,$password);

			mysqli_stmt_execute($statement);

			$data = mysqli_stmt_get_result($statement);

			if($data->num_rows > 0)
			{	
				if($row = mysqli_fetch_assoc($data))
				{	
					$_SESSION['user'] =  $row;
					if($row['is_active']=="InActive"){
					$msg="Dear User you are InActive ";
					header("location: home-page.php?msg=$msg&color=red");	
					}
					if($row['is_approved']=="Pending"){
					$msg="Dear User you are in Pending ";
					header("location: home-page.php?msg=$msg&color=red");	
					}
					elseif($row['is_approved']=="Rejected"){
					$msg="Dear User you are Rejected ";
					header("location: home-page.php?msg=$msg&color=red");	
					}
					elseif($row['role_id'] == 1){
					header("location: admin/admin.php");	
					}
					elseif($row['role_id'] == 2){
					header("location: user/register-user-dashboard.php");	
					}

			    }
			else
			{
				$msg = "Login Failed Plz Try Again ";
				header("location: home-page.php?msg=$msg&color=red");
			}

		 }  

	 }
?>