<!DOCTYPE html>
<html>
<head>
  <title>Online Blogging Application</title>
  <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
  <style type="text/css">
    
  </style>
 
</head>
<body>
         <!-- Navbar Start -->
          <?php include_once("navbar-for-admin.php"); ?>
         <!-- Navbar End -->

        <!-- Add Post -->
         <div class="row my-5 text-center" id="add_post">
        <div class="col">
          <h2 class="text-uppercase fw-bolder" style="text-decoration-thickness:5px; text-decoration-color: #F6B608 ;  text-underline-offset:15px; color: black;" id="about_us_heading"> Update Post </h2>
        </div>
      </div>

      <div class="fw-bold mx-auto col-10 col-md-8 col-lg-6">
        <form class="row g-3 needs-validation text-center " novalidate>
      <div class="col-md-10 text-center ">
        <label for="validationCustom01" class="form-label">Update Post Title</label>
        <input type="text" class="form-control" id="validationCustom01"  required>
        <div class="valid-feedback">
          Update a Post title
        </div>
      </div>
      
     <div class="col-md-10">
        <label for="validationCustomUsername" class="form-label">Update  Summary</label>
        <div class="input-group has-validation">
          <textarea class="form-control" id="validationCustomUsername" aria-describedby="inputGroupPrepend" required></textarea>
          <div class="invalid-feedback">
            please Update a Summary
          </div>
        </div>
      </div>

     <div class="col-md-10">
        <label for="validationCustomUsername" class="form-label">Update Description</label>
        <div class="input-group has-validation">
          <textarea class="form-control" id="validationCustomUsername" aria-describedby="inputGroupPrepend" required></textarea>
          <div class="invalid-feedback">
            please Update a Post Description
          </div>
        </div>
      </div>

      <div class="fw-bold mx-auto col-10 col-md-8 col-lg-6">
        <form class="row g-3 needs-validation text-center " novalidate>
        <div class="col-md-10 text-center ">
          <label for="validationCustom01" class="form-label">Update a Image</label>
          <input type="file" class="form-control" id="validationCustom01"  required>
          <div class="valid-feedback">
        </div>
      </div>

     <div class="col-6">
       <label for="validationCustomUsername" class="form-label mt-3">Update Post Status</label>
        <div class="form-check">
          <input class="form-check-input" type="checkbox" value="" id="invalidCheck" required>
          <label class="form-check-label" for="invalidCheck">
            Active Post
          </label>
          <div class="invalid-feedback">
            You must agree before submitting.
          </div>
        </div>
         <div class="form-check">
          <input class="form-check-input" type="checkbox" value="" id="invalidCheck" required>
          <label class="form-check-label" for="invalidCheck">
            InActive Post
          </label>
          <div class="invalid-feedback">
            You must agree before submitting.
          </div>
        </div>
      </div>

       <div class="col-6">
       <label for="validationCustomUsername" class="form-label mt-4">Update Comment User Show / Not</label>
        <div class="form-check">
          <input class="form-check-input" type="checkbox" value="" id="invalidCheck" required>
          <label class="form-check-label" for="invalidCheck">
            Show Comment
          </label>
          <div class="invalid-feedback">
            You must agree before submitting.
          </div>
        </div>
         <div class="form-check">
          <input class="form-check-input" type="checkbox" value="" id="invalidCheck" required>
          <label class="form-check-label" for="invalidCheck">
            Hide Comment
          </label>
          <div class="invalid-feedback">
            You must agree before submitting.
          </div>
        </div>
      </div>

      <div class="col-6">
        <div class="form-check my-3">
          <input class="form-check-input" type="checkbox" value="" id="invalidCheck" required>
          <label class="form-check-label" for="invalidCheck">
            Agree to terms and conditions
          </label>
          <div class="invalid-feedback">
            You must agree before submitting.
          </div>
        </div>
      </div>

      <div class="col-12 ">
        <button class="btn btn-primary my-2 mx-2" type="submit">Update Post</button>
        <button class="btn btn-primary my-2 mx-2" type="submit">Delete Post</button>
      </div>
      
    </form>
  </div>
  <script type="text/javascript" src="bootstrap/js/bootstrap.bundle.min.js"></script>
</body>
</html>

        <!-- Add Post End-->