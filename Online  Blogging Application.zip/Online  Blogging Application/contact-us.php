 <div class="row my-5 text-center text-white" id="contact_us">
            <div class="col">
              <h1 class="text-uppercase fw-bolder" style="text-decoration-thickness:5px; text-decoration-color: #F6B608 ;  text-underline-offset:15px; color: white;" id="about_us_heading"> Contact Us </h1>
            </div>
          </div>

              <div class="fw-bold mx-auto col-10 col-md-8 col-lg-6">
                <form action="" method="POST" class="row g-3 needs-validation text-center " novalidate>
                  <div class="col-md-10 text-center ">
                    <label for="validationCustom01" class="form-label">Full Name</label>
                    <input type="text" name="name" class="form-control" id="validationCustom01"  required>
                  </div>
                  
                  <div class="col-md-10 text-center">
                    <label for="validationCustomUsername" class="form-label">Email</label>
                    <div class="input-group has-validation ">
                      
                      <input type="text" name="email" class="form-control"  id="validationCustomUsername" aria-describedby="inputGroupPrepend" required>
                      <div class="invalid-feedback">
                        Please choose a email.
                      </div>
                    </div>
                  </div>

                  <div class="col-md-10">
                    <label for="validationCustomUsername" class="form-label">Feedback Message</label>
                    <div class="input-group has-validation">
                      <textarea class="form-control" name="feedback_message" id="validationCustomUsername" aria-describedby="inputGroupPrepend" required></textarea>
                      <div class="invalid-feedback">
                        Please give feedback
                      </div>
                    </div>
                  </div>
                
                  <div class="col-12">
                    <input type="submit" name="feedback_submit" value="Submit" class="btn btn-primary my-2 mx-auto" style="width: 20%;">
                  </div>
                </form>
             </div>


             <?php
    date_default_timezone_set("asia/karachi");
      require_once 'database-files/connection.php';

      if (isset($_REQUEST['feedback_submit'])) {
            extract($_POST);

              $time = date("Y-m-d h:i:s a");
              

            $insert = "INSERT INTO `user_feedback`(user_name,user_email,feedback,created_at,updated_at)
          VALUES('".$name."','".$email."','".$feedback_message."','".$time."','".$time."')"; 
            if($result= mysqli_query($connection,$insert)){ ?>
              <div id="message">
              <h3 style="color: white; background-color: green; text-align: center; font-weight: bolder;">Feedback Submit Successfully</h3>

              </div>
             <?php
              }else
                { ?>

                <div id="message">
                  <h3 style="color: white; background-color: red; text-align: center; font-weight: bolder;">Feedback Submit Successfully</h3>
                </div>
              
                <?php
                }

             } 

         ?>

          <script type="text/javascript">
                 setInterval(function(){
                  document.getElementById("message").innerHTML = "";
                      },5000);
              </script>