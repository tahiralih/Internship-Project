<div class="col-12 text-white bg-dark">
        
                      <!-- Contact us -->
        
         <div class="row my-5 text-center text-white" id="contact_us">
        <div class="col">
          <h1 class="text-uppercase fw-bolder" style="text-decoration-thickness:5px; text-decoration-color: #F6B608 ;  text-underline-offset:15px; color: white;" id="about_us_heading"> Contact Us </h1>
        </div>
      </div>


       <div class="fw-bold mx-auto col-10 col-md-8 col-lg-6">
        <form action="" method="POST" class="row g-3 needs-validation text-center " novalidate>
      <div class="col-md-10 text-center ">
        <label for="validationCustom01" class="form-label">Feedback Message</label>
        <textarea class="form-control" name="feedback_message" id="validationCustomUsername" aria-describedby="inputGroupPrepend" required></textarea>
       
      </div>
     

      <div class="col-12">
       <input type="submit" name="feedback_submit" value="Feedback Submit" class="btn btn-primary my-2 mx-auto" style="width: 18%;">
      </div>
    </form>
  </div>
   <?php
      date_default_timezone_set("asia/karachi");
      require_once '../database-files/connection.php';

      if (isset($_REQUEST['feedback_submit'])) {
            extract($_POST);
            $time = date("Y-m-d h:i:s a");  
              $user_id= $_SESSION['user']['user_id'];  
              $name= $_SESSION['user']['first_name'];
              $email= $_SESSION['user']['email'];

            $insert = "INSERT INTO `user_feedback`(user_id,user_name,user_email,feedback,created_at,updated_at)
          VALUES('".$user_id."','".$name."','".$email."','".$feedback_message."','".$time."','".$time."')"; 
            if($result= mysqli_query($connection,$insert)){ ?>
               <div id="message">
              <h3 style="color: white; background-color: green; text-align: center; font-weight: bolder; height: 40px;">Feedback Submit Successfully</h3> 
              </div>
             <?php
              }else
                { ?>

                <div id="message">
                  <h3 style="color: white; background-color: red; text-align: center; font-weight: bolder; height: 40px;">Feedback not Submit </h3>
                </div>
              
                <?php
               }

             } 

         ?>

          <script type="text/javascript">
                 setInterval(function(){
                  document.getElementById("message").innerHTML = "";
                      },5000);
              </script>


            </div>
              <!-- Contact us End-->