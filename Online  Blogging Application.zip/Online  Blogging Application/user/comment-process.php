 <?php
 session_start();
   require_once '../database-files/connection.php';
      if (isset($_REQUEST['comment_submit'])) {

            extract($_POST);
            // print_r($_POST);
            // echo $post_id;
            // die();
              //$_GET['post_id'];
              // die();

            $time = date("Y-m-d h:i:s a");  
            $user_id= $_SESSION['user']['user_id'];

            $insert = "INSERT INTO `post_comment`(post_id,user_id,comment)
            VALUES('".$post_id."','".$user_id."','".$comment."')"; 
            if($result= mysqli_query($connection,$insert)){ 
            $msg = "";
    
              $msg = "Your comment was Submitted Sucessfully ";
              header("location: post-readmore-page.php?post_id=$post_id&msg=$msg&color=green");

            }
            else
            {
              $msg = "comment not Submitted";
              header("location: post-readmore-page.php?msg=$msg&color=red");
            }

             } 

         ?>
          

