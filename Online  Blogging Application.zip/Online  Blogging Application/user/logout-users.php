<?php 

	session_start();
	session_destroy();

	header("location: ../home-page.php?msg=Logout Successfully !...&color=green")


?>