<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">

    <title>About Us</title>
    <style>
     

        .team {
            display: flex;
            justify-content: space-between;
            flex-wrap: wrap;
        }

        .team-members {
            width: 100%;
            margin-bottom: 20px;
            padding: 10px;
            text-align: center;
        }

        .team-members img {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            margin: 0 auto 10px;
            display: block;
        }

        .team-members h3 {
            margin: 0;
        }

        .team-members p {
            margin-top: 5px;
        }


           </style>
</head>
<body>
  <div class="container-fluid" id="about_us">
   <h1 class="text-uppercase fw-bolder text-center" style="text-decoration-thickness:5px; text-decoration-color: #F6B608 ;  text-underline-offset:15px; color: black;" id="about_us_heading"> About Us </h1>
    <div class="row">
      <div class="col-md-8">
        <h5 class="text-uppercase fw-bolder" style="text-decoration-thickness:5px; text-decoration-color: #F6B608 ;  text-underline-offset:15px; " id="about_us_heading"> Our Team Members </h5>
        <div class="team">
          <div class="col-2">
            <div class="team-members">
              <img src="images/4.png" alt="Team Member 1">
              <h3 class=" fw-bold">Tahir Ali</h3>
              <p>Position: CEO</p>
              <p>Description: Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
            </div>
          </div>

          <div class="col-2">
            <div class="team-members">
              <img src="images/1.jpg" alt="Team Member 1">
              <h3 class="fw-bold">Hasnain Ali</h3>
              <p>Position: HR Manager</p>
              <p>Description: Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
            </div>
          </div>

          <div class="col-2">
            <div class="team-members">
              <img src="images/2.jpg" alt="Team Member 1">
              <h3 class=" fw-bold">Ahsan Ali</h3>
              <p>Position: Software Programmer</p>
              <p>Description: Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
            </div>
          </div>

          <div class="col-2">
            <div class="team-members">
              <img src="images/3.png" alt="Team Member 1">
              <h3 class=" fw-bold">Ali Khan</h3>
              <p>Position: Instructor</p>
              <p>Description: Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
            </div>
          </div>
        </div>
      </div>

      <div class="col-md-4">
        <img class="vision-image" src="images/about-us.jpg" alt="No Image" width="100%" height="100%">
      </div>
    </div>
  </div>

  <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>
</body>
</html>
