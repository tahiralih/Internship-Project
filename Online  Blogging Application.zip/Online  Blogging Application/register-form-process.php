<?php 
		//require for email
	use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\SMTP;
    use PHPMailer\PHPMailer\Exception;

    require 'PHPMailer/src/PHPMailer.php';
    require 'PHPMailer/src/SMTP.php';
    require 'PHPMailer/src/Exception.php'; 
        //require for email end

    require_once("FPDF/fpdf.php"); //require for pdf
	require_once("database-files/connection.php"); //require for database connection
	date_default_timezone_set("asia/karachi");
	
	if(isset($_POST['register']))
	{

	extract($_REQUEST);
	
	$alpha_pattern  	    = "/^[A-Z]{1}[a-z]{2,}$/";
	$email_pattern   		= "/^[a-z]{2,30}[0-9]{1,5}[@][a-z]{3,10}[.][a-z]{1,8}$/";
	$password_pattern 		= "/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,20}$/";
	$address_pattern  		= "/^[A-Z][a-z]{1,}$/";
	$date_of_birth_pattern  = "/^\d{4}-\d{2}-\d{2}$/";

	$flag = true;
	$error_msg = null;

	if ($first_name == "") {
		$flag = false;
		$error_msg.="<li>Please Enter the First Name !...</li>";
	}else{

		if( !preg_match($alpha_pattern, $first_name) ){
			$flag = false;
		    $error_msg.="<li>First Name must be like eg : Tahir !...</li>";
		}
	}

	if ($last_name == "") {
		$flag = false;
		$error_msg.="<li>Please Enter the Last Name !...</li>";
	}else{

		if( !preg_match($alpha_pattern, $last_name) ){
			$flag = false;
		    $error_msg.="<li>Last Name must be like eg : Hingoro !...</li>";
		}
	}

	if ($email == "") {
		$flag = false;
		$error_msg.="<li>Please Enter the Email !...</li>";
	}else{

		if( !preg_match($email_pattern, $email) ){
			$flag = false;
		    $error_msg.="<li>Email must be like eg : tahirali12@gmail.com !...</li>";
		}
	}

	if ($password == "") {
		$flag = false;
		$error_msg.="<li>Please Enter the Password !...</li>";
	}else{

		if( !preg_match($password_pattern, $password) ){
			$flag = false;
		    $error_msg.="<li>Password between 7 to 15 characters one numeric digit and a special character e.g Tahir/1!...</li>";
		}
	}

	if (!isset($gender)) {
		$flag = false;
		    $error_msg.="<li>Please Select Gender !...</li>";
	}

	  if (!preg_match($date_of_birth_pattern, $date_of_birth)) {
        $flag = false;
        $error_msg .= "<li>Please enter a valid Date of Birth (YYYY-MM-DD)!</li>";
      } 



	if ($address == "") {
		$flag = false;
		$error_msg.="<li>Please Enter the Address!...</li>";
	}else{

		if( !preg_match($address_pattern, $address) ){
			$flag = false;
		    $error_msg.="<li>Please Adress must be like Hyderabad!...</li>";
		}
	}

	// if (!isset($image)) {
	// 	$flag = false;
	// 	    $error_msg.="<li>Please Select Image !...</li>";
	// }


	

	if ($flag == false) {
		
		header("location:register-page.php?message=".$error_msg);
	}
		// print_r($_FILES);
		$folder = "User_Profile";
		if(!is_dir($folder)){
			if(!mkdir($folder)){
				$message = "Folder Not Created";
				header("location:register-page.php?msg=$message&color=red");
				die;
			}
		}
		$originalname  = $_FILES['user_image']['name'];
		$filename 	=  rand()."_".$_FILES['user_image']['name'];
		$temp_name 	= $_FILES['user_image']['tmp_name'];
		$file_path     = $folder."/".$filename;

		move_uploaded_file($temp_name, $folder."/".$filename);

		// print_r($_POST);
		$time = date("Y-m-d h:i:s a");
		               
		$insertUserQuery = "INSERT INTO `user`(first_name,last_name,email,password,gender,date_of_birth,user_image,address,created_at,updated_at )
		VALUES(?,?,?,?,?,?,?,?,?,?)"; 

		$insert = mysqli_prepare($connection,$insertUserQuery);

		mysqli_stmt_bind_param($insert,'ssssssssss',$first_name,$last_name,$email,$password,$gender,$date_of_birth,$file_path,$address,$time,$time);

		$msg = "";
		if(mysqli_stmt_execute($insert))
		{


		$mail = new PHPMailer();
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->Port = 587;
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->SMTPAuth = true;
        $mail->Username = 'mr.intern11@gmail.com';
        $mail->Password = 'sqgumlcmvjtcumgt';
        $mail->setFrom($email, $first_name);
        $mail->addReplyTo($email, 'User');
        // $mail->AddCc($email);
        $mail->addAddress('mr.intern11@gmail.com', 'Admin');
        $mail->Subject = 'New User Registration';
        $mail->msgHTML("A new user has registered with the following details:\n\nName: $first_name\nEmail: $email\nPassword: $password");
        $mail->send();



        $mail = new PHPMailer();
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->Port = 587;
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->SMTPAuth = true;
        $mail->Username = 'mr.intern11@gmail.com';
        $mail->Password = 'sqgumlcmvjtcumgt';
        $mail->setFrom('mr.intern11@gmail.com', 'Mr Intern');
        $mail->addReplyTo('mr.intern11@gmail.com', 'Hidaya Intern');
        $mail->AddCc('mr.intern11@gmail.com');
        $mail->AddBcc('dralih@gmail.com');
        $mail->addAddress($email, $first_name);
        $mail->Subject = 'Registration on the Online Blogging Application Plateform';
        $mail->msgHTML('Please be patient your request has been sent to admin ..');
        $mail->send();
        //mail sent end 
    	
			// for create time pdf generate user data
			$userData = array(
			    'first_name' => $first_name,
			    'last_name' => $last_name,
			    'password' => $password,
			    'email' => $email,
			    'gender' => $gender,
			    'date_of_birth' => $date_of_birth,
			    'address' => $address,
			    'user_image' => $file_path,

			);
			$pdf = new FPDF();
			$pdf->AddPage();

			$pdf->SetFont('Arial','B',16);
			$pdf->Cell(0,10,"You are Successfully Registered Mr: " .$userData['first_name']." ".$userData['last_name'],0,2,'C');
			$pdf->Cell(0,10,'Your Record',0,1,'C');
			
			$pdf->SetFont('Arial','',12);
			$pdf->SetDrawColor(230, 0, 0);
			$pdf->Image($userData['user_image'],130,30,30,30,'JPG','');
			$pdf->Cell(40,10,'Name:');
			$pdf->Cell(0,10,$userData['first_name']." ".$userData['last_name'],0,1);
			$pdf->Cell(40,10,'Password:');
			$pdf->Cell(0,10,$userData['password'],0,1);

			$pdf->Cell(40,10,'Email:');
			$pdf->Cell(0,10,$userData['email'],0,1);

			$pdf->Cell(40,10,'Gender:');
			$pdf->Cell(0,10,$userData['gender'],0,1);

			$pdf->Cell(40,10,'Date of Birth:');
			$pdf->Cell(0,10,$userData['date_of_birth'],0,1);

			$pdf->Cell(40,10,'Address:');
			$pdf->Cell(0,10,$userData['address'],0,1);


			$pdf->Output("I");
			// for create time pdf generate user data end



		} 
		else
		{
			$msg = "You are Not Registered ";
			header("location: register-page.php?msg=$msg&color=red");
		}



	}


?>