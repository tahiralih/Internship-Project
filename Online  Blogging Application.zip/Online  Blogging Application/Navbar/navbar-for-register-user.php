 <!DOCTYPE html>
 <html>
 <head>
   <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <title>OnlineBloggingApllication</title>
   <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
   <style type="text/css">
     #dropdownnav{
      background-color: #0080ff;
      color: white;
      font-weight: bold;
     }
   </style>
 </head>
 <body>
 


<?php


 ?>
 <!-- Navbar -->
 
    <nav class="navbar navbar-expand-lg  sticky-top " style="background-color: #0080ff;  ">
        <div class="container-fluid">
          <img src="../images/logo.png" alt="" width="80px">
          <a class="navbar-brand text-white " href="#"><b>ONLINE BLOGGING APPLICATION</b></a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarScroll" aria-controls="navbarScroll" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarScroll">
            <ul class="navbar-nav me-auto my-2 my-lg-0 navbar-nav-scroll" style="--bs-scroll-height: 100px;">
              <li class="nav-item">
                <?php

                    $role_id = $_SESSION['user']['role_id'];
                    if ($role_id == 2) {
                        ?>
                      <a class="nav-link active text-white fw-bold text-center" aria-current="page" href="register-user-dashboard.php">Home</a>
                        <?php  
                    } else {
                        ?>
                     <a class="nav-link active text-white fw-bold " aria-current="page" href="admin.php">Home</a>
                        <?php  
                      }
                 ?>
               
              </li>

                <?php

                    $role_id = $_SESSION['user']['role_id'];
                    if ($role_id == 2) {
                        ?>
                        <li class="nav-item">
                          <a class="nav-link text-white fw-bold " href="#about_us">About Us</a>
                        </li>
                        <li class="nav-item">
                          <a class="nav-link text-white fw-bold " href="#contact_us">Contact us</a>
                        </li>
                            <?php
            require_once '../database-files/connection.php';
                      $get_blog = "SELECT * FROM `blog`;";
                      $blog = mysqli_query($connection, $get_blog);
                    ?>

                    <li class="nav-item dropdown ">
                        <a class="nav-link dropdown-toggle text-white" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Blogs
                        </a>
                        <ul class="dropdown-menu  bg-primary text-black">
                              <?php 
                                    while ($row = mysqli_fetch_assoc($blog)) 
                                    {
                                        ?><li><a class="dropdown-item text-black" href="blog.php?blog_id=<?php echo $row['blog_id']; ?>" >
                                            <?php echo $row['blog_title']; ?> 
                                        </a></li>
                    
                                        <?php   
                                    }

                                ?>
                        </ul>
                    </li> 


                    <?php
                      $get_category= "SELECT * FROM `category`;";
                      $category = mysqli_query($connection, $get_category);
                    ?>

                    <li class="nav-item dropdown ">
                        <a class="nav-link dropdown-toggle text-white" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Category
                        </a>
                        <ul class="dropdown-menu  bg-primary text-black">
                              <?php 
                                    while ($row = mysqli_fetch_assoc($category)) 
                                    {
                                        ?><li><a class="dropdown-item text-black" href="../user/category.php?category_id=<?php echo $row['category_id']; ?>" >
                                            <?php echo $row['category_title']; ?> 
                                        </a></li>
                    
                                        <?php   
                                    }

                                ?>
                        </ul>
                    </li> 
                        <?php } 
                   else { 

                      }
                     ?>
            
            </ul>
           
            
             <div class="dropdown" >
                <button class="btn btn-white text-white dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">

               <?php
                   

                     $role_id = $_SESSION['user']['role_id'];

                    if ($role_id == 2) {
                        ?>
                        <img src="../<?php echo $_SESSION['user']['user_image']; ?>" width="20px" height="20px">
                        <?php  
                        echo $_SESSION['user']['first_name']." ".$_SESSION['user']['last_name'];
                    } else {
                        ?>
                        <img src="../<?php echo $_SESSION['user']['user_image']; ?>" width="20px" height="20px">
                        <?php  
                         echo $_SESSION['user']['first_name']." ".$_SESSION['user']['last_name'];
                    }
                ?>


                </button>
                <ul class="dropdown-menu dropdown-menu-primary">
                  <li><a class="dropdown-item active" href="register-user-dashboard.php">Dashboard</a></li>
                  <li><a class="dropdown-item" href="../Edit-Profile/user-edit-profile.php">Profile</a></li>
                  <li><a class="dropdown-item" href="../home-page.php">Logout</a></li>
                  <li><hr class="dropdown-divider"></li>
                </ul>
              </div>
          </div>
        </div>
    </nav>

    <script type="text/javascript" src="bootstrap/js/bootstrap.bundle.min.js"></script>
   
     
  </body>
 </html>
  <!-- Navbar