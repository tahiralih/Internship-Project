<?php
	require_once("database-files/connection.php");
	use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\SMTP;
    use PHPMailer\PHPMailer\Exception;

    require 'PHPMailer/src/PHPMailer.php';
    require 'PHPMailer/src/SMTP.php';
    require 'PHPMailer/src/Exception.php'; 

if(isset($_POST['forget_password']))
	{
	    $email =$_POST['email'];
	    $dumypassword= rand(1000,9999);



	       $forget_password_query = "UPDATE `user` SET password = ?
			WHERE `user`.`email` = ?";

			$statement = mysqli_prepare($connection,$forget_password_query);

			mysqli_stmt_bind_param($statement,'ss',$dumypassword,$email);


			$result = mysqli_stmt_execute($stmt);

			if($result)
			{

					$mail = new PHPMailer();
			        $mail->isSMTP();
			        $mail->Host = 'smtp.gmail.com';
			        $mail->Port = 587;
			        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
			        $mail->SMTPAuth = true;
			        $mail->Username = 'mr.intern11@gmail.com';
			        $mail->Password = 'sqgumlcmvjtcumgt';
			        $mail->setFrom('mr.intern11@gmail.com', 'Mr Admin');
			        $mail->addReplyTo('mr.intern11@gmail.com', 'Mr Admin');
			        $mail->addAddress($email, 'User');
			        $mail->Subject = 'For forget Password';
			        $mail->msgHTML("Dear User your Password will be Updated of Online Blogging Application Platform :now your new password is: $dumypassword");
			        $mail->send();

				$msg = "Your Password will be Updated Please Check Email:";
				header("location: forget-password.php?msg=$msg&color=green");	
			}else{
						
				$msg = "Inavlid Email/Not Registered";
			 	header("location: forget-password.php?msg=$msg&color=red");			

			}

	  



}


?>