  <!DOCTYPE html>
  <html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>OnlineBloggingApplication</title>
   
  </head>
  <body>
  
  <?php
    require 'database-files/connection.php';

            $select_query = "SELECT * FROM POST
INNER JOIN BLOG
ON POST.`blog_id`=BLOG.`blog_id` 
 WHERE POST.`post_status`='Active' AND BLOG.`blog_status`='Active'
  ORDER BY POST.`updated_at` DESC LIMIT 3";
            $result = mysqli_query($connection,$select_query);

            if(mysqli_num_rows($result) > 0)
            {
      
              ?>

      <div class="col-12">
        <h1> Recent Posts</h1> 
        <?php
         while ($row = mysqli_fetch_assoc($result)) 
              { ?>
                <div class="card mb-3" style="max-width: 100%;">
                  <div class="row g-0">
                    <div class="col-md-4">
                      <img src="admin/<?php echo $row['featured_image']; ?>" class="img-fluid rounded-start" alt="No Recents Posts" width="100%" height="100%">
                    </div>
                    <div class="col-md-8">
                      <div class="card-body">
                        <h5 class="card-title"><?php echo $row['post_title']; ?></h5>
                        <p class="card-text"><?php echo $row['post_summary']; ?></p>
                        <p class="card-text"><small class="text-body-secondary"></small></p>
                      </div>
                    </div>
                  </div>
                </div>
              <?php } ?>
      </div>
     <?php }
          else{
            echo "No Posts";
          }
      ?>
    </body>
  </html>