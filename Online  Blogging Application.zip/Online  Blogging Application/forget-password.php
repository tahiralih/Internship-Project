<!DOCTYPE html>
<html>
<head>
	<title>forgetPassword</title>
	<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
	<style type="text/css">
		body{
			background-image: url("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ00U1W_4q88vajgQUdiXnr21vooMCRzohjdnRPPCXjc11tchvWXia4m_25wxUq98CwLxQ&usqp=CAU");
			background-repeat: no-repeat;
			background-size: cover;

		}
	</style>
</head>
<body>
		 <!-- Navbar  -->
      <?php include_once("navbar.php"); ?>
         <!-- Navbar End -->

        <?php include_once("login-page.php"); ?>

             <script type="text/javascript">
                 setInterval(function(){
                  document.getElementById("message").innerHTML = "";
                      },5000);
              </script>

                <?php 
                    if(isset($_REQUEST['msg'])){
                      ?>
                      <div id="message" style="text-align: center;"><?php  echo "<h3 style='color:".$_REQUEST['color']."'>".$_REQUEST['msg']."</h3>";?> 
                      </div>
                 <?php
                     
                    }
                 ?>
        <div class="container">
        	<h1 class="text-center fw-bold my-3 text-white">FORGET PASSWORD</h1>
         <form class="row" action="forget-password-process.php" method="POST">
		  <div class="col-md-12 my-5">
		    <label for="validationDefaultUsername" class="form-label fw-bolder text-white">Email</label>
		    <div class="input-group">
		      <span class="input-group-text" id="inputGroupPrepend2">@</span>
		      <input type="text" name="email" class="form-control p-3" placeholder="Please type a email" id="validationDefaultUsername" aria-describedby="inputGroupPrepend2" required>
		    </div>
		   </div>
		  
		  <div class="col-12 my-3">
		    
		    <center>
		  
		    	<input  type="submit" name="forget_password" value="Forget Password"  class="btn bg-primary text-white fw-bold text-center">
		  
		    </center>
		  </div>
		</form>
		</div>

	 <div class="fixed-bottom">
       <?php 
          include_once("footer.php");
        ?>
     </div>

<script type="text/javascript" src="bootstrap/js/bootstrap.bundle.min.js"></script>

</body>
</html>