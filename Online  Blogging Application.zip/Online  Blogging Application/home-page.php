<?php  
require 'database-files/connection.php';
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>OnlineBloggingApplication</title>
 
  <style type="text/css">
    .links_category_blog{
      text-decoration: none;
      font-weight: bolder;
      font-family: cursive;
    }
    .links_category_blog:hover{
      color: green;
    }

  </style>
 

</head>
<body>
     
          
      <!-- Navbar  -->
      <?php include_once("navbar.php"); ?>
         <!-- Navbar End -->
        
           <script type="text/javascript">
                 setInterval(function(){
                  document.getElementById("message").innerHTML = "";
                      },5000);
              </script>


                

                <?php 
                    if(isset($_GET['msg'])){
                      ?>
                      <div id="message" style="text-align: center;"><?php  echo "<h3 style='color:".$_REQUEST['color']."'>".$_REQUEST['msg']."</h3>";?> 
                      </div>
                 <?php
                     
                    }
                 ?>

             <!-- Login  -->
          <?php include_once("login-page.php"); ?>
             <!--  End -->
     
      
      <!-- 2 Column Layout -->
      <div class="row ">
        <!-- First Column -->
         <div class="col-9  text-center p-2 fw-bolder ">

          <?php
           $select_query_for_post = "SELECT  BLOG.`blog_id`, BLOG.`blog_title`, BLOG.`blog_status`, BLOG.`blog_background_image`,POST.`post_title`,POST.`featured_image`,POST.`post_id`,
               POST.`created_at`,POST.`updated_at`,POST.`post_status`, POST.`post_summary`,POST.`post_description`,POST.`updated_at`,CATEGORY.`category_title`, CATEGORY.`category_description`
              FROM POST 
              INNER JOIN BLOG
              ON BLOG.`blog_id`=POST.`blog_id`
              INNER JOIN POST_CATEGORY
              ON POST.`post_id`=POST_CATEGORY.`post_id`
              INNER JOIN CATEGORY
              ON POST_CATEGORY.`category_id`=CATEGORY.`category_id`
              WHERE POST.`post_status`='ACTIVE' AND BLOG.`blog_status`='Active'
               ORDER BY POST.`updated_at` DESC;";  
            $result = mysqli_query($connection,$select_query_for_post);

            if(mysqli_num_rows($result) > 0)
            {   
            while ($row= mysqli_fetch_assoc($result)) {
              
            ?>
            <!-- Post  -->
              <div class="container">
               <div class="card mb-3" style="max-width: 100%;">
                  <div class="row g-0">
                    <div class="col-md-4">
                      <img src="admin/<?php  echo $row['featured_image'];  ?>" width="100%" height="100%">
                     
                    </div>
                    <div class="col-md-8">
                      <div class="card-body">
                        <div class="row">
                          <div class="col-6">
                            <a class="links_category_blog" href="blog-for-home.php?blog_id=<?php echo $row['blog_id'];?>"><h5 class="card-title">
                            <?php echo $row['blog_title'];  ?>
                            </h5></a>
                          </div>
                           <div class="col-6">
                            <h5 class="card-title">
                              <?php  echo $row['category_title'];  ?>
                            </h5>
                          </div>
                         
                          <h5 class="card-title">
                            <?php  echo $row['post_title'];  ?>
                          </h5>
                        </div>
                        
                        <p class="card-text">
                          <?php  echo $row['post_summary'];  ?>
                        </p>
                        <p class="card-text" style="text-align: right;"><small class="text-body-secondary"><?php  echo $row['updated_at'];  ?></small></p>
                            <a href="post-readmore-page.php?post_id=<?php echo $row['post_id'];?>" class="btn btn-primary" >Read More</a>

                      </div>
                    </div>
                  </div>
                </div>
              </div>

             <?php   
               } }
              else{
                echo "No Blogs";
              }
              ?>

              

            <!-- Post End-->

          </div>
              <!-- First Column End -->
         

          <!-- Second Column -->
            <div class="col-3 text-center p-2 fw-bolder ">

            <!--Recent News  -->
              <?php  include("recent-news.php"); ?>
             <!-- Recent News -->

            </div>
         <!-- Second Column End -->
         
      </div>


       
          <div class="col-12 text-center p-2 fw-bolder bg-dark text-white" style="background-color: #0080ff;">
 
              <!-- Contact Us -->
                <?php include_once("contact-us.php"); ?>
              <!-- Contact us End -->
          </div>             

       
           <?php include_once("about-us.php"); ?>
         

        <?php 
          include_once("footer.php");
        ?>
        

</body>
</html>