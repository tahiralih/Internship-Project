    <!-- Modal Login -->
      <div class="modal fade" id="staticBackdropLogin" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">

              <h1 class="modal-title fs-5" id="staticBackdropLabel">Login Here</h1>
              
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
              
              <form method="POST" action="login-process.php" class="row g-3 needs-validation" novalidate>
            <div class="col-md-12 position-relative">
              <label for="validationTooltipUsername" class="form-label">Email</label>
              <div class="input-group has-validation">
                <input type="text" name="email" placeholder="Enter a Email" class="form-control" id="validationTooltipUsername" aria-describedby="validationTooltipUsernamePrepend" required>
                <div class="invalid-tooltip">
                  Please choose a unique and valid Email.
                </div>
              </div>
            </div>
            <div class="col-md-12 position-relative">
              <label for="validationTooltipPassword" class="form-label">Password</label>
              <div class="input-group has-validation">
                <input type="password" name="password" placeholder="Enter a Password" class="form-control" id="validationTooltipPassword" aria-describedby="validationTooltipUsernamePrepend" required>
                <div class="invalid-tooltip">
                  Password Must be 8 to 12 Characters
                </div>
              </div>
            </div>
            <div class="col-12">
            </div>
            </div>
            <div class="modal-footer">                   
               <!-- <button type="button" class="btn btn-primary" data-bs-dismiss="modal">Forget</button> -->
               <a href="forget-password.php" class="btn  btn-primary">Forget Here </a>
              <a href=""><button class="btn  btn-primary" type="submit" name="login">Login Here</button></a>
              
            </div>
            </form>
          </div>
        </div>
      </div>
    <!-- Modal Login End -->