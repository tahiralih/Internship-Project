 <!DOCTYPE html>
 <html>
 <head>
   <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <title>OnlineBloggingAPllication</title>
 </head>
 <body>
 

      <!-- Footer -->
        
      <div class="row ">
        <div class="col-12 text-center p-3 fw-bold " style="max-width:100%; background-color: #0080ff;" >
          <p>@Copyright <?php date_default_timezone_set("Asia/karachi");
          echo date("Y");
           ?></p>
        </div>
      </div>

      <!-- Footer End -->

   </body>
 </html>